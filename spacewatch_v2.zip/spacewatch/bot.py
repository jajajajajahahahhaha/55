"""Telegram layer (v2): handlers, fan-out delivery, video, health commands.

Highlights
* Video delivery (sendVideo with poster + duration) & file_id reuse: the
  file is uploaded once and re-used for every other user -> N× less bandwidth.
* Global token-bucket rate limiter (Telegram: ~30 msg/s, 1 msg/s per chat).
* Per-user mute & video opt-out; strict admin checks; command flood guard.
* /status, /sources, /latest, /video, /lang, /mute, /unmute, /novideo, /yesvideo.
* Robust: every send is wrapped, RetryAfter is honoured, Forbidden removes
  the user, unexpected errors never kill the broadcaster.
"""
import asyncio
import html
import json
import logging
import os
import re
import time
import zipfile
from collections import defaultdict

from telegram import (BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, InputFile,
                      Update)
from telegram.error import BadRequest, Forbidden, RetryAfter, TelegramError, TimedOut
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler, ContextTypes)
from telegram.request import HTTPXRequest

import config
import database as db
import tunnel
from i18n import LANGS, tr

log = logging.getLogger("bot")

HIST_RE = re.compile(r"(\d+)\s*([mMhHdD])")
UNITS = {"m": 60, "h": 3600, "d": 86400}
START_TS = time.time()


# ---------- helpers ----------------------------------------------------------
def region_of(img, lang):
    keys = img.keys() if hasattr(img, "keys") else []
    if lang != "fa" and "region_en" in keys and img["region_en"]:
        return img["region_en"]
    r = img["region"] or ""
    if r.startswith("["):                       # legacy JSON pair
        try:
            fa, en = json.loads(r)
            return fa if lang == "fa" else en
        except Exception:
            pass
    return r


def fmt_dur(seconds, lang):
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f"{seconds} {tr(lang, 'sec')}"
    if seconds < 3600:
        return f"{seconds // 60} {tr(lang, 'min')}"
    if seconds < 86400:
        return f"{seconds // 3600} {tr(lang, 'hour')} {(seconds % 3600) // 60} {tr(lang, 'min')}"
    return f"{seconds // 86400} {tr(lang, 'day')} {(seconds % 86400) // 3600} {tr(lang, 'hour')}"


def fmt_size(b):
    b = b or 0
    return f"{b / 1024 / 1024:.1f} MB" if b >= 1024 * 1024 else f"{b / 1024:.0f} KB"


def glass_buttons(img, lang):
    row = [InlineKeyboardButton(tr(lang, "orig_btn"), callback_data=f"orig:{img['id']}")]
    if img["repaired_path"]:
        row.append(InlineKeyboardButton(tr(lang, "rep_btn"), callback_data=f"rep:{img['id']}"))
    row.append(InlineKeyboardButton(tr(lang, "info_btn"), callback_data=f"info:{img['id']}"))
    return InlineKeyboardMarkup([row])


def caption_for(img, lang):
    it = img["img_time"] or img["fetched_at"]
    delay = max(0, (img["fetched_at"] or time.time()) - it)
    is_video = img["kind"] == "video"
    title = tr(lang, "cap_video" if is_video else "cap_title")
    lines = [f"{'🎬' if is_video else '🛰️'} <b>{title}</b>",
             f"📍 {tr(lang, 'region')}: {html.escape(region_of(img, lang) or '—')}",
             f"🕐 {tr(lang, 'time')}: {time.strftime('%Y-%m-%d %H:%M', time.gmtime(it))} UTC",
             f"⏱️ {tr(lang, 'delay')}: {fmt_dur(delay, lang)}",
             f"📡 {tr(lang, 'sat')}: {html.escape(img['sat'] or '')}"]
    if img["width"]:
        lines.append(f"🖼️ {tr(lang, 'quality')}: {img['width']}×{img['height']}")
    if is_video and img["duration"]:
        lines.append(f"⏳ {tr(lang, 'duration')}: {int(img['duration'])} {tr(lang, 'sec')}")
    lines.append(f"📦 {tr(lang, 'size')}: {fmt_size(img['size'])}")
    if not is_video:
        st = tr(lang, "st_partial" if img["status"] == "partial" else "st_complete")
        lines.append(f"🔖 {tr(lang, 'status')}: {st}")
    if time.time() - it > config.MAX_ITEM_AGE:
        lines.append(tr(lang, "too_old_note"))
    return "\n".join(lines)[:1024]


class RateLimiter:
    """Global ~25 msg/s + per-chat 1 msg/s (Telegram limits)."""

    def __init__(self):
        self.last_chat = defaultdict(float)
        self.global_ts = []

    async def wait(self, chat_id):
        now = time.time()
        gap = 1.05 - (now - self.last_chat[chat_id])
        if gap > 0:
            await asyncio.sleep(gap)
        self.global_ts = [t for t in self.global_ts if now - t < 1]
        if len(self.global_ts) >= 25:
            await asyncio.sleep(1 - (now - self.global_ts[0]))
        self.global_ts.append(time.time())
        self.last_chat[chat_id] = time.time()


RL = RateLimiter()


async def _tg(coro_fn, *a, **kw):
    """Call a telegram method with RetryAfter / timeout handling."""
    for attempt in range(3):
        try:
            return await coro_fn(*a, **kw)
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 0.5)
        except TimedOut:
            await asyncio.sleep(2 * (attempt + 1))
    return await coro_fn(*a, **kw)


async def send_media(tgbot, chat_id, img, lang, kind="new"):
    """Send an image or video; re-use Telegram file_id when available."""
    cap = caption_for(img, lang)
    if kind == "completed":
        cap = tr(lang, "completed_follow") + "\n\n" + cap
    kb = glass_buttons(img, lang)
    size = img["size"] or 0
    await RL.wait(chat_id)

    if img["kind"] == "video":
        if size > config.MAX_VIDEO_MB * 1024 * 1024:
            link = await tunnel.publish_file(img["path"])
            text = cap + "\n\n📦 " + (link or tr(lang, "no_tunnel"))
            await _tg(tgbot.send_message, chat_id, text, parse_mode="HTML",
                      disable_web_page_preview=True)
            return
        if img["tg_file_id"]:
            try:
                await _tg(tgbot.send_video, chat_id, img["tg_file_id"], caption=cap,
                          parse_mode="HTML", reply_markup=kb, supports_streaming=True)
                return
            except BadRequest:
                pass
        thumb = None
        if img["thumb_path"] and os.path.exists(img["thumb_path"]):
            thumb = open(img["thumb_path"], "rb")
        try:
            with open(img["path"], "rb") as f:
                msg = await _tg(tgbot.send_video, chat_id, InputFile(f, filename=os.path.basename(img["path"])),
                                caption=cap, parse_mode="HTML", reply_markup=kb,
                                duration=int(img["duration"] or 0) or None,
                                width=img["width"] or None, height=img["height"] or None,
                                thumbnail=thumb, supports_streaming=True,
                                read_timeout=180, write_timeout=180)
            if msg and msg.video:
                db.update_media(img["id"], tg_file_id=msg.video.file_id)
        finally:
            if thumb:
                thumb.close()
        return

    # ---- image ----
    if img["tg_file_id"] and size <= config.MAX_TG_PHOTO and not img["thumb_path"]:
        try:
            await _tg(tgbot.send_photo, chat_id, img["tg_file_id"], caption=cap,
                      parse_mode="HTML", reply_markup=kb)
            return
        except BadRequest:
            pass
    if size > config.MAX_TG_DOC:
        # too big even as a document -> preview (downscaled) + link
        if img["thumb_path"] and os.path.exists(img["thumb_path"]):
            with open(img["thumb_path"], "rb") as f:
                await _tg(tgbot.send_photo, chat_id, f, caption=cap, parse_mode="HTML",
                          reply_markup=kb)
        link = await tunnel.publish_file(img["path"])
        await _tg(tgbot.send_message, chat_id, "📦 " + (link or tr(lang, "no_tunnel")),
                  disable_web_page_preview=True)
    elif size > config.MAX_TG_PHOTO or img["thumb_path"]:
        # send a viewable photo (downscaled) + the original as document
        if img["thumb_path"] and os.path.exists(img["thumb_path"]):
            with open(img["thumb_path"], "rb") as f:
                msg = await _tg(tgbot.send_photo, chat_id, f, caption=cap, parse_mode="HTML",
                                reply_markup=kb)
        with open(img["path"], "rb") as f:
            await RL.wait(chat_id)
            await _tg(tgbot.send_document, chat_id, InputFile(f, filename=os.path.basename(img["path"])),
                      caption=None if img["thumb_path"] else cap, parse_mode="HTML",
                      reply_markup=None if img["thumb_path"] else kb,
                      disable_content_type_detection=True, read_timeout=180, write_timeout=180)
    else:
        with open(img["path"], "rb") as f:
            msg = await _tg(tgbot.send_photo, chat_id, f, caption=cap, parse_mode="HTML",
                            reply_markup=kb, read_timeout=120, write_timeout=120)
        if msg and msg.photo:
            db.update_media(img["id"], tg_file_id=msg.photo[-1].file_id)
    if img["repaired_path"] and kind == "new" and os.path.exists(img["repaired_path"]):
        try:
            await RL.wait(chat_id)
            with open(img["repaired_path"], "rb") as f:
                await _tg(tgbot.send_photo, chat_id, f, caption=tr(lang, "repaired_caption"))
        except Exception as e:
            log.debug("repaired send failed: %s", e)


def is_admin(chat_id):
    adm = db.cfg("admin_id")
    return adm is not None and str(chat_id) == str(adm)


def lang_of(chat_id):
    db.ensure_user(chat_id)
    return db.get_user_lang(chat_id)


# ---------- command flood guard ---------------------------------------------
_last_cmd = defaultdict(list)


def _flood(chat_id, limit=6, window=10):
    now = time.time()
    _last_cmd[chat_id] = [t for t in _last_cmd[chat_id] if now - t < window]
    if len(_last_cmd[chat_id]) >= limit:
        return True
    _last_cmd[chat_id].append(now)
    return False


def guarded(fn):
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not update.effective_chat or not update.message:
            return
        cid = update.effective_chat.id
        if _flood(cid):
            await update.message.reply_text(tr(lang_of(cid), "rate_wait"))
            return
        try:
            await fn(update, ctx)
        except Forbidden:
            db.remove_user(cid)
        except Exception as e:
            log.warning("handler %s failed: %s", fn.__name__, e)
    return wrapper


def admin_only(fn):
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        cid = update.effective_chat.id
        if not is_admin(cid):
            await update.message.reply_text(tr(lang_of(cid), "admin_only"))
            return
        await fn(update, ctx)
    wrapper.__name__ = fn.__name__
    return wrapper


# ---------- command handlers -------------------------------------------------
def lang_keyboard():
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton(f"{flag} {label}", callback_data=f"lang:{code}")
          for code, label, flag in LANGS[i:i + 2]] for i in range(0, len(LANGS), 2)])


@guarded
async def cmd_start(update: Update, ctx):
    cid = update.effective_chat.id
    db.ensure_user(cid)
    await update.message.reply_text(tr("fa", "choose_lang") + "\n" + tr("en", "choose_lang"),
                                    reply_markup=lang_keyboard())


@guarded
async def cmd_lang(update: Update, ctx):
    await update.message.reply_text(tr(lang_of(update.effective_chat.id), "choose_lang"),
                                    reply_markup=lang_keyboard())


async def on_lang(update: Update, ctx):
    q = update.callback_query
    await q.answer()
    code = q.data.split(":", 1)[1]
    if code not in {c for c, _, _ in LANGS}:
        return
    cid = q.message.chat_id
    db.ensure_user(cid)
    db.set_user_lang(cid, code)
    await q.edit_message_text(tr(code, "lang_saved"))
    await q.message.reply_text(tr(code, "welcome"))
    await q.message.reply_text(tr(code, "help"), parse_mode="HTML")
    if not db.flag("public") and not is_admin(cid):
        await q.message.reply_text(tr(code, "not_public"))


@guarded
async def cmd_help(update: Update, ctx):
    await update.message.reply_text(tr(lang_of(update.effective_chat.id), "help"),
                                    parse_mode="HTML")


async def _send_rows(ctx, cid, lang, rows, kind="new"):
    for img in reversed(rows):   # oldest first
        try:
            await send_media(ctx.bot, cid, img, lang, kind)
        except Forbidden:
            raise
        except TelegramError as e:
            log.debug("send rows: %s", e)


@guarded
async def cmd_latest(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    rows = db.latest_media(6)
    if not rows:
        await update.message.reply_text(tr(lang, "hist_none"))
        return
    await _send_rows(ctx, cid, lang, rows)


@guarded
async def cmd_video(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    rows = db.latest_media(3, kind="video")
    if not rows:
        await update.message.reply_text(tr(lang, "no_video"))
        return
    await _send_rows(ctx, cid, lang, rows)


@guarded
async def cmd_history(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    m = HIST_RE.search(update.message.text or "")
    if not m:
        await update.message.reply_text(tr(lang, "hist_usage"))
        return
    n, unit = int(m.group(1)), m.group(2).lower()
    delta = min(n * UNITS[unit], 30 * 86400)
    first_run = float(db.cfg("first_run") or time.time())
    if time.time() - first_run < delta:
        await update.message.reply_text(
            tr(lang, "uptime_less").format(have=fmt_dur(time.time() - first_run, lang)))
    limit = 12 if is_admin(cid) else 8
    rows = db.media_since(time.time() - delta, limit=limit)
    if not rows:
        await update.message.reply_text(tr(lang, "hist_none"))
        return
    if len(rows) == limit:
        await update.message.reply_text(tr(lang, "hist_max").format(n=limit))
    await _send_rows(ctx, cid, lang, rows)


REGION_ALIAS = {"us": "US", "usa": "US", "آمریکا": "US", "eu": "EU", "europe": "EU", "اروپا": "EU",
                "cn": "CN", "china": "CN", "چین": "CN", "jp": "JP", "japan": "JP", "asia": "JP",
                "mx": "MX", "mexico": "MX", "sun": "sun", "خورشید": "sun", "sdo": "sdo",
                "space": "webb", "فضا": "webb", "hubble": "hubble", "webb": "webb", "jwst": "webb",
                "earth": "epic", "زمین": "epic", "epic": "epic"}


@guarded
async def cmd_region(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    q = " ".join(ctx.args or []).strip()
    if not q:
        await update.message.reply_text(tr(lang, "region_usage"))
        return
    q = REGION_ALIAS.get(q.lower(), q)
    rows = db.find_region(q, limit=1)
    if not rows:
        await update.message.reply_text(tr(lang, "region_none"))
        return
    await send_media(ctx.bot, cid, rows[0], lang)


@guarded
async def cmd_iran(update: Update, ctx):
    """Latest Iran / Persian Gulf image (Meteosat-9 IODC / MTG)."""
    cid = update.effective_chat.id
    lang = lang_of(cid)
    rows = db.find_region("iran", limit=1)
    if not rows:
        await update.message.reply_text(tr(lang, "region_none"))
        return
    await send_media(ctx.bot, cid, rows[0], lang)


@guarded
@admin_only
async def cmd_source(update: Update, ctx):
    """/source <key> on|off  — enable/disable a single source."""
    from sources import SOURCE_MAP
    cid = update.effective_chat.id
    lang = lang_of(cid)
    args = ctx.args or []
    if len(args) != 2 or args[0] not in SOURCE_MAP or args[1].lower() not in ("on", "off"):
        keys = ", ".join(sorted(SOURCE_MAP))
        await update.message.reply_text(f"/source <key> on|off\n\n{keys}"[:4000])
        return
    on = args[1].lower() == "on"
    db.src_set_enabled(args[0], on)
    db.event("info", f"source {args[0]} -> {'on' if on else 'off'} (admin)")
    await update.message.reply_text(f"{'🟢' if on else '⚫'} {args[0]} → {'ON' if on else 'OFF'}")


@guarded
async def cmd_mute(update: Update, ctx):
    cid = update.effective_chat.id
    db.set_user_flag(cid, "muted", True)
    await update.message.reply_text(tr(lang_of(cid), "muted"))


@guarded
async def cmd_unmute(update: Update, ctx):
    cid = update.effective_chat.id
    db.set_user_flag(cid, "muted", False)
    await update.message.reply_text(tr(lang_of(cid), "unmuted"))


@guarded
async def cmd_novideo(update: Update, ctx):
    cid = update.effective_chat.id
    db.set_user_flag(cid, "want_video", False)
    await update.message.reply_text(tr(lang_of(cid), "video_off"))


@guarded
async def cmd_yesvideo(update: Update, ctx):
    cid = update.effective_chat.id
    db.set_user_flag(cid, "want_video", True)
    await update.message.reply_text(tr(lang_of(cid), "video_on"))


@guarded
async def cmd_sources(update: Update, ctx):
    from sources import region_text, source_catalog
    cid = update.effective_chat.id
    lang = lang_of(cid)
    cat = source_catalog()
    states = {s["key"]: s for s in db.src_all()}
    now = time.time()
    lines = [tr(lang, "sources_title").format(n=len(cat))]
    for s in cat:
        st = states.get(s["key"], {})
        if not st.get("enabled", 1):
            ic = tr(lang, "src_off")
        elif st.get("fails", 0) >= 3:
            ic = tr(lang, "src_bad")
        elif st.get("fails", 0) or (st.get("last_ok") and now - st["last_ok"] > 3600):
            ic = tr(lang, "src_warn")
        else:
            ic = tr(lang, "src_ok")
        ago = f" · {fmt_dur(now - st['last_new'], lang)}" if st.get("last_new") else ""
        k = "🎬" if "video" in s["kind"] else "🖼"
        lines.append(f"{ic}{k} <b>{html.escape(s['sat'])}</b> — "
                     f"{html.escape(region_text(s['region'], lang))}{ago}")
    text = "\n".join(lines)
    for i in range(0, len(text), 3900):
        await update.message.reply_text(text[i:i + 3900], parse_mode="HTML")


@guarded
@admin_only
async def cmd_status(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    c = db.counts()
    mgr = ctx.application.bot_data.get("mgr")
    eng = ctx.application.bot_data.get("engine")
    mem = _rss_mb()
    lines = [tr(lang, "status_title"),
             f"⏱ uptime: {fmt_dur(time.time() - START_TS, lang)}",
             f"👥 users: {c['u']} · 🖼 images: {c['i']} · 🎬 videos: {c['v']} · ⚠️ partial: {c['p']}",
             f"📥 last 24h: {c['last24']} · 💾 media: {fmt_size(db.disk_usage())}",
             f"🧠 RAM: {mem:.0f} MB · queue: {mgr.queue.qsize() if mgr else '?'}",
             f"🔁 poll rounds: {eng.rounds if eng else '?'} · last round: "
             f"{eng.round_ms / 1000 if eng else 0:.1f}s · interval {config.POLL_INTERVAL}s"
             + (f" · new {eng.stats['new']} / 304 {eng.stats['not_modified']} / err {eng.stats['errors']}" if eng else ""),
             f"🌍 public: {'ON' if db.flag('public') else 'OFF'} · 🎬 video: "
             f"{'ON' if config.ENABLE_VIDEO else 'OFF'}"]
    bad = [s for s in db.src_all() if s["fails"] >= 3]
    if bad:
        lines.append("🔴 failing: " + ", ".join(f"{s['key']}({s['fails']})" for s in bad[:10]))
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


def _rss_mb():
    try:
        import psutil
        return psutil.Process().memory_info().rss / 1e6
    except Exception:
        try:
            with open("/proc/self/status") as f:
                for line in f:
                    if line.startswith("VmRSS"):
                        return int(line.split()[1]) / 1024
        except Exception:
            pass
    return 0.0


def _build_zip():
    zpath = os.path.join(config.FILE_DIR, f"all_media_{int(time.time())}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_STORED) as z:   # media is compressed already
        for d, sub in ((config.IMG_DIR, "images"), (config.VID_DIR, "videos")):
            for f in sorted(os.listdir(d)):
                if f.startswith("tmp_"):
                    continue
                z.write(os.path.join(d, f), f"{sub}/{f}")
    return zpath


@guarded
@admin_only
async def cmd_all(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    await update.message.reply_text(tr(lang, "all_wait"))
    zpath = await asyncio.to_thread(_build_zip)
    size = os.path.getsize(zpath)
    if size > config.MAX_TG_DOC:
        link = await tunnel.publish_file(zpath, "all_media.zip")
        await update.message.reply_text(tr(lang, "all_big") + "\n" + (link or tr(lang, "no_tunnel")))
    else:
        with open(zpath, "rb") as f:
            await ctx.bot.send_document(cid, f, filename="all_media.zip",
                                        read_timeout=300, write_timeout=300)
        os.remove(zpath)


@guarded
@admin_only
async def cmd_public(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    cur = db.flag("public")
    arg = (ctx.args[0].lower() if ctx.args else "")
    new = (arg in ("on", "1", "روشن")) if arg else not cur
    db.setcfg("public", "1" if new else "0")
    db.event("info", f"public mode -> {new}")
    await update.message.reply_text(tr(lang, "public_on" if new else "public_off"))


@guarded
@admin_only
async def cmd_broadcast(update: Update, ctx):
    cid = update.effective_chat.id
    lang = lang_of(cid)
    text = (update.message.text or "").split(None, 1)
    if len(text) < 2:
        await update.message.reply_text("/broadcast <text>")
        return
    n = await broadcast_text(ctx.bot, text[1])
    await update.message.reply_text(tr(lang, "broadcast_done").format(n=n))


async def broadcast_text(tgbot, text):
    n = 0
    for u in db.get_users(active_only=False):
        try:
            await RL.wait(u["chat_id"])
            await _tg(tgbot.send_message, u["chat_id"], text[:4000])
            n += 1
        except Forbidden:
            db.remove_user(u["chat_id"])
        except TelegramError as e:
            log.debug("broadcast to %s: %s", u["chat_id"], e)
    return n


# ---------- inline buttons ---------------------------------------------------
async def on_button(update: Update, ctx):
    q = update.callback_query
    cid = q.message.chat_id
    lang = lang_of(cid)
    try:
        action, img_id = q.data.split(":", 1)
        img = db.get_media(int(img_id))
    except Exception:
        await q.answer("bad request", show_alert=True)
        return
    if not img:
        await q.answer("not found", show_alert=True)
        return
    if action == "info":
        txt = (f"{img['sat']}\n{region_of(img, lang)}\n{img['url'][:120]}\n"
               f"#{img['hash'][:10]} • {img['width']}×{img['height']} • {fmt_size(img['size'])}")
        await q.answer(txt[:195], show_alert=True)
    elif action == "rep":
        if img["repaired_path"] and os.path.exists(img["repaired_path"]):
            await q.answer()
            await RL.wait(cid)
            with open(img["repaired_path"], "rb") as f:
                await ctx.bot.send_photo(cid, f, caption=tr(lang, "repaired_caption"))
        else:
            await q.answer(tr(lang, "no_repaired"), show_alert=True)
    elif action == "orig":
        await q.answer()
        if not os.path.exists(img["path"]):
            await q.message.reply_text("🗑 file expired (retention)")
            return
        if (img["size"] or 0) > config.MAX_TG_DOC:
            link = await tunnel.publish_file(img["path"])
            await q.message.reply_text(link or tr(lang, "no_tunnel"))
        else:
            await RL.wait(cid)
            with open(img["path"], "rb") as f:
                await ctx.bot.send_document(cid, InputFile(f, filename=os.path.basename(img["path"])),
                                            disable_content_type_detection=True,
                                            read_timeout=180, write_timeout=180)


# ---------- manager ----------------------------------------------------------
class BotManager:
    def __init__(self, queue, engine=None):
        self.queue = queue
        self.engine = engine
        self.app = None
        self._bc = None
        self.running = False
        self.started_at = 0
        self.sent_total = 0
        self.last_error = None

    async def start(self):
        if self.running:
            return True
        token = db.cfg("bot_token")
        if not token:
            return False
        req = HTTPXRequest(connection_pool_size=16, read_timeout=60, write_timeout=60,
                           connect_timeout=20, pool_timeout=20)
        self.app = (Application.builder().token(token).request(req)
                    .get_updates_request(HTTPXRequest(connection_pool_size=2, read_timeout=65))
                    .concurrent_updates(8).build())
        self.app.bot_data["mgr"] = self
        self.app.bot_data["engine"] = self.engine
        self._register(self.app)
        await self.app.initialize()
        try:
            await self.app.bot.set_my_commands([
                BotCommand("start", "🚀 شروع / Start"),
                BotCommand("latest", "🆕 آخرین موارد / Latest"),
                BotCommand("history", "🕐 تصاویر گذشته — /history 6H"),
                BotCommand("iran", "🇮🇷 آخرین تصویر ایران / Iran"),
                BotCommand("region", "📍 آخرین تصویر منطقه — /region iran"),
                BotCommand("video", "🎬 آخرین ویدیوها / Videos"),
                BotCommand("sources", "📡 منابع و وضعیت / Sources"),
                BotCommand("mute", "🔕 قطع دریافت خودکار"),
                BotCommand("unmute", "🔔 وصل دریافت خودکار"),
                BotCommand("novideo", "🎬❌ بدون ویدیو"),
                BotCommand("yesvideo", "🎬✅ با ویدیو"),
                BotCommand("lang", "🌐 زبان / Language"),
                BotCommand("help", "📚 راهنما / Help"),
                BotCommand("status", "🩺 وضعیت (ادمین)"),
                BotCommand("all", "🗂 همه فایل‌ها ZIP (ادمین)"),
                BotCommand("public", "🌍 حالت عمومی (ادمین)"),
                BotCommand("broadcast", "📣 پیام همگانی (ادمین)"),
            ])
        except TelegramError as e:
            log.debug("set_my_commands: %s", e)
        await self.app.start()
        await self.app.updater.start_polling(drop_pending_updates=True,
                                             allowed_updates=["message", "callback_query"])
        self._bc = asyncio.create_task(self._broadcaster(), name="broadcaster")
        self.running = True
        self.started_at = time.time()
        db.event("info", "telegram bot started")
        log.info("telegram bot started")
        return True

    async def stop(self):
        if not self.running and not self.app:
            return
        if self._bc:
            self._bc.cancel()
            self._bc = None
        try:
            if self.app.updater.running:
                await self.app.updater.stop()
            await self.app.stop()
            await self.app.shutdown()
        except Exception as e:
            log.debug("stop: %s", e)
        self.app = None
        self.running = False
        db.event("info", "telegram bot stopped")
        log.info("telegram bot stopped")

    async def restart(self):
        await self.stop()
        await asyncio.sleep(1)
        return await self.start()

    def healthy(self):
        """Used by the watchdog."""
        if not self.running or not self.app:
            return False
        if self._bc is None or self._bc.done():
            return False
        try:
            return bool(self.app.updater.running)
        except Exception:
            return False

    def _register(self, app):
        for name, fn in (("start", cmd_start), ("help", cmd_help), ("history", cmd_history),
                         ("region", cmd_region), ("iran", cmd_iran), ("source", cmd_source),
                         ("latest", cmd_latest), ("video", cmd_video),
                         ("sources", cmd_sources), ("mute", cmd_mute), ("unmute", cmd_unmute),
                         ("novideo", cmd_novideo), ("yesvideo", cmd_yesvideo), ("lang", cmd_lang),
                         ("status", cmd_status), ("all", cmd_all), ("public", cmd_public),
                         ("broadcast", cmd_broadcast)):
            app.add_handler(CommandHandler(name, fn))
        app.add_handler(CallbackQueryHandler(on_lang, pattern=r"^lang:[a-z]{2}$"))
        app.add_handler(CallbackQueryHandler(on_button, pattern=r"^(orig|rep|info):\d+$"))
        app.add_error_handler(self._on_error)

    async def _on_error(self, update, ctx):
        self.last_error = str(ctx.error)[:200]
        log.warning("telegram error: %s", ctx.error)

    def _targets(self, img):
        public = db.flag("public")
        users = db.get_users() if public else []
        targets = {}
        for u in users:
            if img["kind"] == "video" and not u["want_video"]:
                continue
            targets[u["chat_id"]] = u["lang"]
        adm = db.cfg("admin_id")
        if adm:
            u = db.get_user(int(adm))
            if not u or not u["muted"]:
                if not (img["kind"] == "video" and u and not u["want_video"]):
                    targets.setdefault(int(adm), u["lang"] if u else "fa")
        return targets

    async def _broadcaster(self):
        while True:
            try:
                img_id, kind = await self.queue.get()
                img = db.get_media(img_id)
                if not img or not self.app:
                    continue
                for cid, lang in self._targets(img).items():
                    try:
                        await send_media(self.app.bot, cid, img, lang, kind)
                        self.sent_total += 1
                        img = db.get_media(img_id)   # refresh: tg_file_id may be set now
                    except Forbidden:
                        db.remove_user(cid)
                    except Exception as e:
                        self.last_error = str(e)[:200]
                        log.debug("send to %s failed: %s", cid, e)
                db.update_media(img_id, sent=1)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("broadcaster: %s", e)
                await asyncio.sleep(1)
