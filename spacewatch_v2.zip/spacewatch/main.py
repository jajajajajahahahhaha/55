"""SpaceWatch Bot v2 — entry point.

Runs, in one asyncio loop:
  * Telegram bot (python-telegram-bot, long polling)
  * Source polling engine (parallel, conditional requests)
  * Web panel  :8080  (setup / control / health)
  * File server :8090 (localhost, behind cloudflared for big files)
  * Watchdog   — self-healing: restarts dead tasks, restarts the Telegram
                 layer if it stalls, trims memory, enforces retention.

Memory budget: designed to idle < 150 MB RSS and stay < 700 MB under load.
"""
import asyncio
import gc
import logging
import logging.handlers
import os
import signal
import sys
import time

from aiohttp import web

import config
import database as db
import tunnel
from bot import BotManager, _rss_mb
from sources import Engine
from tunnel import file_app
from webui import make_app

log = logging.getLogger("main")


def setup_logging():
    config.ensure_dirs()
    fmt = logging.Formatter("%(asctime)s %(name)s %(levelname)s %(message)s")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    fh = logging.handlers.RotatingFileHandler(config.LOG_PATH, maxBytes=3 * 1024 * 1024,
                                              backupCount=2, encoding="utf-8")
    fh.setFormatter(fmt)
    root.handlers[:] = [sh, fh]
    for noisy in ("httpx", "httpcore", "telegram", "aiohttp.access", "PIL"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def apply_saved_settings():
    iv = db.cfg("poll_interval")
    if iv and iv.isdigit() and 15 <= int(iv) <= 600:
        config.POLL_INTERVAL = int(iv)
    ev = db.cfg("enable_video")
    if ev is not None:
        config.ENABLE_VIDEO = ev == "1"


# ---------------------------------------------------------------------------
async def retention():
    """Delete media older than KEEP_DAYS and enforce MAX_DISK_MB."""
    cutoff = time.time() - config.KEEP_DAYS * 86400
    rows = db.old_media(cutoff)
    removed = _unlink_rows(rows)
    # disk cap: remove oldest first until under limit
    while db.disk_usage() > config.MAX_DISK_MB * 1024 * 1024:
        oldest = db._q("SELECT id, path, repaired_path, thumb_path FROM media "
                       "ORDER BY fetched_at ASC LIMIT 20").fetchall()
        if not oldest:
            break
        removed += _unlink_rows(oldest)
    n = tunnel.cleanup()
    # orphan temp files from interrupted video downloads
    for d in (config.VID_DIR,):
        for f in os.scandir(d):
            if f.name.startswith("tmp_") and time.time() - f.stat().st_mtime > 3600:
                os.remove(f.path)
    if removed or n:
        log.info("retention: removed %s media, %s published files", removed, n)
    db.vacuum()


def _unlink_rows(rows):
    ids = []
    for r in rows:
        for p in (r["path"], r["repaired_path"], r["thumb_path"]):
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass
        ids.append(r["id"])
    db.delete_media_rows(ids)
    return len(ids)


async def watchdog(mgr: BotManager, engine: Engine):
    """Self-healing loop (cheap: runs every 30 s, ~0 CPU)."""
    last_retention = 0
    bot_restarts = 0
    while True:
        try:
            await asyncio.sleep(30)
            # 1) polling engine died?
            if not engine.alive():
                log.warning("engine task dead -> restarting")
                db.event("warn", "poll engine restarted by watchdog")
                engine.start()
            # 2) engine stalled? (no completed round for 10x interval)
            elif engine.last_round_at and time.time() - engine.last_round_at > config.POLL_INTERVAL * 10 + 300:
                log.warning("engine stalled -> restarting")
                db.event("warn", "poll engine stalled; restarted")
                await engine.stop()
                engine.start()
            # 3) telegram layer unhealthy while it should run?
            if db.cfg("bot_token") and db.flag("bot_enabled", True) and not mgr.healthy():
                if mgr.running or mgr.started_at == 0 or time.time() - mgr.started_at > 60:
                    bot_restarts += 1
                    delay = min(300, 10 * bot_restarts)
                    log.warning("telegram layer unhealthy -> restart (#%s, wait %ss)", bot_restarts, delay)
                    db.event("warn", f"telegram layer restarted by watchdog (#{bot_restarts})")
                    await asyncio.sleep(delay)
                    try:
                        await mgr.restart()
                    except Exception as e:
                        log.error("bot restart failed: %s", e)
                        if "rejected" in str(e).lower() or "unauthorized" in str(e).lower():
                            # invalid token: retrying is pointless -> back off 10 min
                            db.event("error", "bot token rejected by Telegram — fix it in the panel")
                            bot_restarts = 60
            else:
                bot_restarts = 0
            # 4) memory guard
            rss = _rss_mb()
            if rss > config.MEM_SOFT_LIMIT_MB:
                gc.collect()
                _malloc_trim()
                log.info("memory soft limit hit (%.0f MB) -> gc/trim", rss)
            if _rss_mb() > config.MEM_HARD_LIMIT_MB:
                log.warning("memory hard limit -> restarting telegram layer")
                db.event("warn", f"memory {rss:.0f} MB > hard limit; bot layer restarted")
                await mgr.restart()
                gc.collect()
                _malloc_trim()
            # 5) retention hourly
            if time.time() - last_retention > 3600:
                last_retention = time.time()
                await retention()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.error("watchdog: %s", e)


def _malloc_trim():
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


# ---------------------------------------------------------------------------
async def main():
    setup_logging()
    db.init()
    apply_saved_settings()
    log.info("SpaceWatch v2 starting (pid %s)", os.getpid())

    queue = asyncio.Queue(maxsize=500)
    engine = Engine(queue)
    mgr = BotManager(queue, engine)

    ui = make_app(mgr, engine)
    runner = web.AppRunner(ui, access_log=None)
    await runner.setup()
    await web.TCPSite(runner, config.WEB_HOST, config.WEB_PORT, reuse_address=True).start()

    frunner = web.AppRunner(file_app(), access_log=None)
    await frunner.setup()
    await web.TCPSite(frunner, "127.0.0.1", config.FILE_PORT, reuse_address=True).start()

    engine.start()
    wd = asyncio.create_task(watchdog(mgr, engine), name="watchdog")

    if db.cfg("bot_token"):
        try:
            await mgr.start()
        except Exception as e:
            log.error("autostart failed: %s (watchdog will retry)", e)
            db.event("error", f"autostart failed: {e}")

    log.info("Web UI:  http://%s:%s", config.WEB_HOST, config.WEB_PORT)
    db.event("info", "service started")

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            pass
    await stop.wait()

    log.info("shutting down…")
    wd.cancel()
    await engine.stop()
    await mgr.stop()
    await tunnel.stop()
    await runner.cleanup()
    await frunner.cleanup()


if __name__ == "__main__":
    if sys.version_info < (3, 10):
        sys.exit("Python 3.10+ required")
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
