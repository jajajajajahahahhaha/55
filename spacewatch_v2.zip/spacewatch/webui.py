"""Web control panel on :8080 (v2).

Security
* First-run setup creates an **admin password** (min 8 chars); the numeric
  Telegram id alone is no longer enough to log in.
* Passwords are stored as salted PBKDF2-SHA256; sessions are random tokens
  stored hashed in SQLite (HttpOnly, SameSite=Strict cookie).
* Login brute-force lock-out per IP; CSRF token required for every POST;
  security headers; no state leaks to anonymous visitors.
* Bot token is never sent back to the browser (only masked).

UI
* Single-page, renders **once**; live numbers are patched in place with
  `textContent` so inputs never reset while typing (the old bug).
* Token field with show/hide + paste button + live validation via getMe.
* Cards: status, control, public mode, sources health table, recent items,
  events/log, broadcast, settings (poll interval, video on/off), logout.
"""
import hashlib
import hmac
import logging
import os
import secrets
import time
from collections import defaultdict

import aiohttp
from aiohttp import web

import config
import database as db
from bot import broadcast_text

log = logging.getLogger("webui")
_login_fail = defaultdict(list)


# ---------------------------------------------------------------- crypto ----
def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000)
    return f"{salt}${dk.hex()}"


def check_pw(pw, stored):
    try:
        salt, _ = stored.split("$", 1)
        return hmac.compare_digest(hash_pw(pw, salt), stored)
    except Exception:
        return False


def _ip(request):
    return request.headers.get("X-Forwarded-For", request.remote or "?").split(",")[0].strip()


def _authed(request):
    return db.session_valid(request.cookies.get("sw_session"))


def _csrf_ok(request):
    tok = request.cookies.get("sw_session") or ""
    want = hashlib.sha256(("csrf:" + tok).encode()).hexdigest()[:32]
    return hmac.compare_digest(request.headers.get("X-CSRF", ""), want)


def _csrf_for(tok):
    return hashlib.sha256(("csrf:" + tok).encode()).hexdigest()[:32]


def _locked(ip):
    now = time.time()
    _login_fail[ip] = [t for t in _login_fail[ip] if now - t < config.LOGIN_WINDOW]
    return len(_login_fail[ip]) >= config.LOGIN_MAX_FAILS


def need_auth(fn):
    async def w(request):
        if not _authed(request):
            return web.json_response({"ok": False, "error": "unauthorized"}, status=401)
        if request.method == "POST" and not _csrf_ok(request):
            return web.json_response({"ok": False, "error": "csrf"}, status=403)
        return await fn(request)
    return w


async def _json(request, limit=64 * 1024):
    if request.content_length and request.content_length > limit:
        raise web.HTTPRequestEntityTooLarge(max_size=limit, actual_size=request.content_length)
    try:
        return await request.json()
    except Exception:
        return {}


# ------------------------------------------------------------------ HTML ----
HTML = r"""<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>🛰️ SpaceWatch</title>
<style>
:root{--bg:#07080a;--fg:#f2f2f2;--mut:#9a9a9a;--card:rgba(255,255,255,.055);--border:rgba(255,255,255,.14);--ok:#30d158;--warn:#ffd60a;--bad:#ff453a;--acc:#fff}
body.light{--bg:#f3f3f3;--fg:#111;--mut:#555;--card:rgba(0,0,0,.045);--border:rgba(0,0,0,.14);--acc:#000}
*{box-sizing:border-box;font-family:Vazirmatn,Tahoma,system-ui,sans-serif}
body{margin:0;background:var(--bg);color:var(--fg);min-height:100vh;transition:background .3s}
header{display:flex;justify-content:space-between;align-items:center;padding:12px 20px;border-bottom:1px solid var(--border);position:sticky;top:0;backdrop-filter:blur(14px);background:color-mix(in srgb,var(--bg) 80%,transparent);z-index:5}
h1{font-size:18px;margin:0}h3{margin:0 0 12px;font-size:15px}
.wrap{max-width:980px;margin:18px auto;padding:0 14px;display:grid;grid-template-columns:1fr;gap:12px}
@media(min-width:760px){.wrap{grid-template-columns:1fr 1fr}.span2{grid-column:1/-1}}
.card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:18px;backdrop-filter:blur(14px)}
button{background:rgba(255,255,255,.10);border:1px solid var(--border);color:var(--fg);padding:9px 16px;border-radius:12px;cursor:pointer;font-size:14px;transition:.15s}
body.light button{background:rgba(0,0,0,.06)}button:hover{filter:brightness(1.25)}button:disabled{opacity:.4;cursor:default}
button.primary{background:var(--acc);color:var(--bg);font-weight:700}
input,textarea,select{width:100%;padding:11px 12px;border-radius:12px;border:1px solid var(--border);background:transparent;color:var(--fg);margin:6px 0;font-size:14px;direction:ltr}
input:focus,textarea:focus{outline:1px solid var(--fg)}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.row>*{flex:1}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px}
.stat{text-align:center;padding:12px 6px;border:1px solid var(--border);border-radius:12px}.stat b{font-size:22px;display:block}
.small{color:var(--mut);font-size:13px;line-height:1.7}.msg{margin-top:8px;font-size:13px;min-height:18px}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-inline-end:6px;vertical-align:middle}
.ok{background:var(--ok)}.warn{background:var(--warn)}.bad{background:var(--bad)}.off{background:#666}
table{width:100%;border-collapse:collapse;font-size:12.5px}td,th{padding:6px 4px;border-bottom:1px solid var(--border);text-align:start;vertical-align:top}th{color:var(--mut);font-weight:600}
.pill{display:inline-block;padding:2px 8px;border-radius:99px;border:1px solid var(--border);font-size:11px;margin-inline-start:6px}
.hidden{display:none!important}.log{max-height:240px;overflow:auto;font-family:ui-monospace,monospace;font-size:12px;direction:ltr;text-align:left;white-space:pre-wrap}
.thumbs{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px}.thumbs a{display:block;border-radius:10px;overflow:hidden;border:1px solid var(--border);position:relative}
.thumbs img{width:100%;height:90px;object-fit:cover;display:block}.thumbs span{position:absolute;bottom:0;left:0;right:0;font-size:10px;padding:3px 5px;background:rgba(0,0,0,.6);color:#fff;direction:ltr}
.hint{font-size:12px;color:var(--mut);margin-top:-2px;margin-bottom:6px}
</style></head><body>
<header><h1>🛰️ <span data-t="title"></span> <span class="pill" id="ver">v2</span></h1>
<div class="row" style="flex:0"><button onclick="toggleTheme()" id="thBtn">🌙</button>
<button onclick="toggleLang()" id="lgBtn">EN</button>
<button onclick="logout()" id="outBtn" class="hidden">⎋</button></div></header>

<!-- ---------- SETUP ---------- -->
<div class="wrap" id="v-setup" class="hidden"><div class="card span2">
 <h3 data-t="setup"></h3>
 <div class="small" data-t="setup_hint"></div>
 <label class="hint" data-t="token"></label>
 <div class="row"><input id="token" autocomplete="off" spellcheck="false" placeholder="123456789:AAH...">
  <button style="flex:0" onclick="togglePw('token')">👁</button><button style="flex:0" onclick="pasteTo('token')">📋</button></div>
 <div class="msg" id="tokmsg"></div>
 <label class="hint" data-t="admin"></label><input id="admin" inputmode="numeric" placeholder="123456789">
 <label class="hint" data-t="pw"></label>
 <div class="row"><input id="pw" type="password" autocomplete="new-password"><button style="flex:0" onclick="togglePw('pw')">👁</button></div>
 <label class="hint" data-t="pw2"></label><input id="pw2" type="password" autocomplete="new-password">
 <button class="primary" onclick="doSetup()" id="setupBtn" data-t="save"></button>
 <div class="msg" id="smsg"></div></div></div>

<!-- ---------- LOGIN ---------- -->
<div class="wrap hidden" id="v-login"><div class="card span2">
 <h3 data-t="login"></h3>
 <div class="row"><input id="loginpw" type="password" autocomplete="current-password" placeholder="••••••••" onkeydown="if(event.key==='Enter')doLogin()"><button style="flex:0" onclick="togglePw('loginpw')">👁</button></div>
 <button class="primary" onclick="doLogin()" data-t="login_btn"></button><div class="msg" id="lmsg"></div>
 <div class="small" data-t="login_hint"></div></div></div>

<!-- ---------- DASHBOARD ---------- -->
<div class="wrap hidden" id="v-dash">
 <div class="card"><h3 data-t="status"></h3>
  <div class="row"><div><span class="dot" id="botdot"></span><b id="botstate"></b></div>
   <button id="botBtn" onclick="botCtl()"></button><button onclick="botCtl('restart')" data-t="restart"></button></div>
  <div class="small" id="botinfo"></div></div>
 <div class="card"><h3 data-t="pub"></h3>
  <button id="pubBtn" onclick="pubCtl()"></button><div class="small" id="pubinfo"></div>
  <hr style="border:0;border-top:1px solid var(--border);margin:12px 0">
  <div class="row"><label class="small" data-t="video"></label><button id="vidBtn" onclick="vidCtl()"></button></div></div>
 <div class="card span2"><div class="grid">
  <div class="stat"><b id="s_users">–</b><span data-t="users"></span></div>
  <div class="stat"><b id="s_imgs">–</b><span data-t="imgs"></span></div>
  <div class="stat"><b id="s_vids">–</b><span data-t="vids"></span></div>
  <div class="stat"><b id="s_24">–</b><span data-t="last24"></span></div>
  <div class="stat"><b id="s_part">–</b><span data-t="part"></span></div>
  <div class="stat"><b id="s_disk">–</b><span data-t="disk"></span></div>
  <div class="stat"><b id="s_ram">–</b>RAM</div>
  <div class="stat"><b id="s_round">–</b><span data-t="round"></span></div>
  <div class="stat"><b id="s_up">–</b><span data-t="up"></span></div></div></div>
 <div class="card span2"><h3 data-t="recent"></h3><div class="thumbs" id="thumbs"></div></div>
 <div class="card span2"><h3 data-t="sources"></h3><div style="overflow:auto"><table id="srcs"></table></div></div>
 <div class="card"><h3 data-t="bc"></h3><textarea id="bctext" rows="3"></textarea>
  <button onclick="doBc()" data-t="send"></button><div class="msg" id="bmsg"></div></div>
 <div class="card"><h3 data-t="settings"></h3>
  <label class="hint" data-t="interval"></label><input id="interval" type="number" min="15" max="600">
  <label class="hint" data-t="newpw"></label><input id="newpw" type="password" autocomplete="new-password">
  <button onclick="saveSettings()" data-t="save2"></button><div class="msg" id="setmsg"></div>
  <div class="small" id="tokinfo"></div></div>
 <div class="card span2"><h3 data-t="events"></h3><div class="log" id="events"></div></div>
</div>

<script>
const S={
fa:{title:'پنل بات رصد فضا',setup:'راه‌اندازی اولیه',setup_hint:'توکن را از @BotFather و آیدی عددی‌ات را از @userinfobot بگیر. یک رمز برای همین پنل هم بساز (حداقل ۸ کاراکتر).',token:'توکن بات تلگرام',admin:'آیدی عددی ادمین (تلگرام)',pw:'رمز پنل وب',pw2:'تکرار رمز',save:'ذخیره و شروع 🚀',status:'وضعیت بات',running:'در حال اجرا',stopped:'خاموش',start:'روشن کردن',stop:'خاموش کردن',restart:'ری‌استارت',pub:'حالت عمومی',pub_on:'🌍 عمومی — روشن',pub_off:'🔒 عمومی — خاموش',pub_on_i:'تصاویر برای همه کاربران ارسال می‌شود.',pub_off_i:'فقط ادمین دریافت می‌کند.',video:'ارسال ویدیو',on:'روشن',off:'خاموش',bc:'پیام همگانی',send:'ارسال 📣',users:'کاربران',imgs:'تصاویر',vids:'ویدیوها',last24:'۲۴ ساعت اخیر',part:'ناقص',disk:'دیسک',round:'دور چک',up:'آپتایم',ok:'انجام شد ✅',err:'خطا',login:'ورود مدیر',login_btn:'ورود',login_hint:'رمزی که در راه‌اندازی ساختی. بعد از ۶ تلاش ناموفق ۱۵ دقیقه قفل می‌شود.',recent:'آخرین دریافتی‌ها',sources:'وضعیت منابع',settings:'تنظیمات',interval:'فاصله چک منابع (ثانیه)',newpw:'رمز جدید پنل (اختیاری)',save2:'ذخیره',events:'رویدادها',tok_ok:'✅ توکن معتبر: @',tok_bad:'❌ توکن نامعتبر',tok_chk:'⏳ بررسی توکن…',pw_short:'رمز حداقل ۸ کاراکتر',pw_mis:'رمزها یکی نیستند',bad_admin:'آیدی عددی درست وارد کن',locked:'قفل شد؛ بعداً تلاش کن',src:'منبع',region:'منطقه',last:'آخرین دریافت',health:'سلامت',ms:'زمان',never:'هنوز نه',enable:'فعال',disable:'غیرفعال'},
en:{title:'SpaceWatch Panel',setup:'First-time setup',setup_hint:'Get the token from @BotFather and your numeric id from @userinfobot. Choose a password for this panel (min 8 chars).',token:'Telegram bot token',admin:'Admin numeric Telegram ID',pw:'Panel password',pw2:'Repeat password',save:'Save & Start 🚀',status:'Bot status',running:'Running',stopped:'Stopped',start:'Start',stop:'Stop',restart:'Restart',pub:'Public mode',pub_on:'🌍 Public — ON',pub_off:'🔒 Public — OFF',pub_on_i:'Images go to every user.',pub_off_i:'Admin only.',video:'Send videos',on:'ON',off:'OFF',bc:'Broadcast',send:'Send 📣',users:'Users',imgs:'Images',vids:'Videos',last24:'Last 24h',part:'Partial',disk:'Disk',round:'Poll round',up:'Uptime',ok:'Done ✅',err:'Error',login:'Admin login',login_btn:'Login',login_hint:'The password you set during setup. 6 failed attempts lock you out for 15 min.',recent:'Recent items',sources:'Source health',settings:'Settings',interval:'Poll interval (seconds)',newpw:'New panel password (optional)',save2:'Save',events:'Events',tok_ok:'✅ Valid token: @',tok_bad:'❌ Invalid token',tok_chk:'⏳ Checking token…',pw_short:'Password: min 8 chars',pw_mis:'Passwords differ',bad_admin:'Enter a numeric id',locked:'Locked; try later',src:'Source',region:'Region',last:'Last new',health:'Health',ms:'Time',never:'never',enable:'enable',disable:'disable'}};
let L=localStorage.lang||'fa',ST=null,CSRF=null,view='';
const t=k=>(S[L][k]??k);
function applyLang(){document.documentElement.lang=L;document.documentElement.dir=L==='fa'?'rtl':'ltr';
 document.querySelectorAll('[data-t]').forEach(e=>e.textContent=t(e.dataset.t));
 document.getElementById('lgBtn').textContent=L==='fa'?'EN':'FA';if(ST)patch(ST)}
function toggleLang(){L=L==='fa'?'en':'fa';localStorage.lang=L;applyLang()}
function toggleTheme(){document.body.classList.toggle('light');localStorage.theme=document.body.classList.contains('light')?'l':'d';document.getElementById('thBtn').textContent=localStorage.theme==='l'?'☀️':'🌙'}
if(localStorage.theme==='l'){document.body.classList.add('light');document.getElementById('thBtn').textContent='☀️'}
function togglePw(id){const e=document.getElementById(id);e.type=e.type==='password'?'text':'password'}
async function pasteTo(id){try{document.getElementById(id).value=(await navigator.clipboard.readText()).trim();checkToken()}catch(e){}}
const v=id=>document.getElementById(id).value,msg=(id,s,bad)=>{const e=document.getElementById(id);e.textContent=s;e.style.color=bad?'var(--bad)':''};
async function post(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF':CSRF||''},body:JSON.stringify(body||{})});let j={};try{j=await r.json()}catch(e){}if(r.status===401){show('login')}return j}
function show(name){if(view===name)return;view=name;['setup','login','dash'].forEach(n=>document.getElementById('v-'+n).classList.toggle('hidden',n!==name));document.getElementById('outBtn').classList.toggle('hidden',name!=='dash')}
// ---- token live check (debounced) ----
let tokT=null;document.getElementById('token').addEventListener('input',()=>{clearTimeout(tokT);tokT=setTimeout(checkToken,600)});
async function checkToken(){const tok=v('token').trim();if(!/^\d+:[\w-]{30,}$/.test(tok)){msg('tokmsg',tok?t('tok_bad'):'',!!tok);return}
 msg('tokmsg',t('tok_chk'));const r=await post('/api/check_token',{token:tok});msg('tokmsg',r.ok?t('tok_ok')+r.username:t('tok_bad'),!r.ok)}
async function doSetup(){const pw=v('pw');if(pw.length<8)return msg('smsg',t('pw_short'),1);if(pw!==v('pw2'))return msg('smsg',t('pw_mis'),1);
 if(!/^\d{5,15}$/.test(v('admin').trim()))return msg('smsg',t('bad_admin'),1);
 document.getElementById('setupBtn').disabled=true;const r=await post('/setup',{token:v('token').trim(),admin_id:v('admin').trim(),password:pw});
 document.getElementById('setupBtn').disabled=false;msg('smsg',r.ok?t('ok'):(t('err')+': '+(r.error||'')),!r.ok);if(r.ok){CSRF=r.csrf;await load(true)}}
async function doLogin(){const r=await post('/api/login',{password:v('loginpw')});if(r.ok){CSRF=r.csrf;document.getElementById('loginpw').value='';await load(true)}else msg('lmsg',r.error==='locked'?t('locked'):t('err'),1)}
async function logout(){await post('/api/logout');CSRF=null;location.reload()}
async function botCtl(a){a=a||(ST.running?'stop':'start');document.getElementById('botBtn').disabled=true;await post('/api/bot',{action:a});setTimeout(()=>load(),900)}
async function pubCtl(){await post('/api/public');load()}
async function vidCtl(){await post('/api/video');load()}
async function doBc(){const r=await post('/api/broadcast',{text:v('bctext')});msg('bmsg',r.ok?t('ok')+' ('+r.sent+')':t('err')+(r.error?': '+r.error:''),!r.ok);if(r.ok)document.getElementById('bctext').value=''}
async function saveSettings(){const r=await post('/api/settings',{interval:+v('interval')||0,password:v('newpw')});msg('setmsg',r.ok?t('ok'):t('err')+(r.error?': '+r.error:''),!r.ok);document.getElementById('newpw').value=''}
async function srcToggle(k,en){await post('/api/source',{key:k,enabled:en});load()}
const fmtUp=s=>{s=Math.floor(s);if(s<3600)return Math.floor(s/60)+'m';if(s<172800)return Math.floor(s/3600)+'h';return Math.floor(s/86400)+'d'};
const ago=ts=>ts?fmtUp(Date.now()/1000-ts):t('never');const mb=b=>b>1e9?(b/1e9).toFixed(1)+' GB':(b/1e6).toFixed(0)+' MB';
const set=(id,val)=>{const e=document.getElementById(id);if(e&&e.textContent!==String(val))e.textContent=val};
function patch(st){
 set('botstate',st.running?t('running'):t('stopped'));document.getElementById('botdot').className='dot '+(st.running?'ok':'bad');
 const bb=document.getElementById('botBtn');bb.disabled=false;set('botBtn',st.running?t('stop'):t('start'));
 set('botinfo',(st.bot_username?'@'+st.bot_username+' · ':'')+'sent: '+st.sent_total+(st.last_error?' · ⚠ '+st.last_error:''));
 set('pubBtn',st.public?t('pub_on'):t('pub_off'));set('pubinfo',st.public?t('pub_on_i'):t('pub_off_i'));
 set('vidBtn',st.video?t('on'):t('off'));
 set('s_users',st.users);set('s_imgs',st.images);set('s_vids',st.videos);set('s_24',st.last24);set('s_part',st.partial);set('s_disk',mb(st.disk));set('s_ram',st.ram_mb.toFixed(0)+' MB');set('s_round',(st.round_ms/1000).toFixed(1)+'s');set('s_up',fmtUp(st.uptime));
 set('tokinfo','token: '+st.token_masked+' · admin: '+st.admin_id+' · poll '+st.interval+'s · engine '+(st.engine_alive?'🟢':'🔴'));
 const iv=document.getElementById('interval');if(document.activeElement!==iv&&iv.value!==String(st.interval))iv.value=st.interval;
 // sources table
 const rows=st.sources.map(s=>{const c=!s.enabled?'off':s.fails>=3?'bad':(s.fails||(s.last_ok&&Date.now()/1000-s.last_ok>3600))?'warn':'ok';
  return `<tr><td><span class="dot ${c}"></span>${s.kind.includes('video')?'🎬':'🖼'} ${esc(s.sat)}</td><td class="small">${esc(L==='fa'?s.region[0]:s.region[1])}</td><td>${ago(s.last_new)}<br><span class="small">${s.total_new}×</span></td><td class="small">${s.avg_ms?Math.round(s.avg_ms)+'ms':''}${s.last_err?'<br>⚠ '+esc(s.last_err.slice(0,60)):''}</td><td><button style="padding:4px 8px;font-size:11px" onclick="srcToggle('${s.key}',${s.enabled?0:1})">${s.enabled?t('disable'):t('enable')}</button></td></tr>`}).join('');
 const tbl=`<tr><th>${t('src')}</th><th>${t('region')}</th><th>${t('last')}</th><th>${t('ms')}</th><th></th></tr>`+rows;
 const el=document.getElementById('srcs');if(el.dataset.h!==hash(tbl)){el.innerHTML=tbl;el.dataset.h=hash(tbl)}
 const th=st.recent.map(r=>`<a href="/media/${r.id}" target="_blank" title="${esc(r.sat)}"><img loading="lazy" src="/thumb/${r.id}" alt=""><span>${r.kind==='video'?'🎬 ':''}${esc(r.src)} · ${ago(r.fetched_at)}</span></a>`).join('');
 const te=document.getElementById('thumbs');if(te.dataset.h!==hash(th)){te.innerHTML=th;te.dataset.h=hash(th)}
 const ev=st.events.map(e=>`${new Date(e.ts*1000).toISOString().slice(5,19).replace('T',' ')} [${e.level}] ${esc(e.msg)}`).join('\n');set('events',ev);
}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hash=s=>{let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return String(h)};
async function load(force){try{const r=await fetch('/api/state',{headers:{'X-CSRF':CSRF||''}});const st=await r.json();
 if(!st.configured){show('setup');return}if(!st.admin){show('login');return}
 if(!CSRF)CSRF=st.csrf;ST=st;show('dash');patch(st)}catch(e){}}
applyLang();load();setInterval(load,5000);
</script></body></html>"""


# --------------------------------------------------------------- handlers ----
SEC_HEADERS = {
    "X-Frame-Options": "DENY", "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer", "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'self'; img-src 'self' data:; style-src 'unsafe-inline'; "
                               "script-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'",
}


@web.middleware
async def sec_mw(request, handler):
    try:
        resp = await handler(request)
    except web.HTTPException as e:
        resp = e
    for k, v in SEC_HEADERS.items():
        resp.headers.setdefault(k, v)
    return resp


async def index(request):
    return web.Response(text=HTML, content_type="text/html")


async def check_token(request):
    """Validate a token with getMe *before* setup — only allowed when not
    configured yet or when authenticated (prevents token-probing oracle)."""
    if db.cfg("bot_token") and not _authed(request):
        return web.json_response({"ok": False}, status=401)
    if _locked(_ip(request)):
        return web.json_response({"ok": False, "error": "locked"}, status=429)
    data = await _json(request)
    tok = (data.get("token") or "").strip()
    if not tok or len(tok) > 100 or ":" not in tok:
        return web.json_response({"ok": False, "error": "bad token"})
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.telegram.org/bot{tok}/getMe",
                             timeout=aiohttp.ClientTimeout(total=15)) as r:
                j = await r.json()
        if j.get("ok"):
            return web.json_response({"ok": True, "username": j["result"].get("username")})
        _login_fail[_ip(request)].append(time.time())
        return web.json_response({"ok": False, "error": "bad token"})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)[:80]})


async def setup(request):
    if db.cfg("bot_token"):
        return web.json_response({"ok": False, "error": "already configured"}, status=409)
    data = await _json(request)
    token = (data.get("token") or "").strip()
    admin_id = (data.get("admin_id") or "").strip()
    pw = data.get("password") or ""
    if not token or not admin_id.isdigit() or len(pw) < 8:
        return web.json_response({"ok": False, "error": "bad input"})
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.telegram.org/bot{token}/getMe",
                             timeout=aiohttp.ClientTimeout(total=15)) as r:
                j = await r.json()
        if not j.get("ok"):
            return web.json_response({"ok": False, "error": "bad token"})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)[:80]})
    db.setcfg("bot_token", token)
    db.setcfg("bot_username", j["result"].get("username", ""))
    db.setcfg("admin_id", admin_id)
    db.setcfg("admin_pw", hash_pw(pw))
    db.ensure_user(int(admin_id))
    db.event("info", "setup completed")
    tok = db.session_create(_ip(request))
    resp = web.json_response({"ok": True, "csrf": _csrf_for(tok)})
    _set_cookie(resp, tok)
    try:
        await request.app["mgr"].start()
    except Exception as e:
        log.warning("autostart after setup failed: %s", e)
    return resp


def _set_cookie(resp, tok):
    resp.set_cookie("sw_session", tok, max_age=config.SESSION_HOURS * 3600, httponly=True,
                    samesite="Strict", path="/")


async def login(request):
    ip = _ip(request)
    if _locked(ip):
        return web.json_response({"ok": False, "error": "locked"}, status=429)
    data = await _json(request)
    pw = data.get("password") or ""
    stored = db.cfg("admin_pw")
    await asyncio_sleep(0.3)   # slow down guessing
    if stored and check_pw(pw, stored):
        _login_fail[ip].clear()
        tok = db.session_create(ip)
        resp = web.json_response({"ok": True, "csrf": _csrf_for(tok)})
        _set_cookie(resp, tok)
        db.event("info", f"panel login from {ip}")
        return resp
    _login_fail[ip].append(time.time())
    db.event("warn", f"failed panel login from {ip}")
    return web.json_response({"ok": False})


async def asyncio_sleep(s):
    import asyncio
    await asyncio.sleep(s)


@need_auth
async def logout(request):
    db.session_drop(request.cookies.get("sw_session"))
    resp = web.json_response({"ok": True})
    resp.del_cookie("sw_session", path="/")
    return resp


async def state(request):
    configured = bool(db.cfg("bot_token"))
    authed = _authed(request)
    base = {"configured": configured, "admin": authed}
    if not authed:
        return web.json_response(base)     # nothing else leaks to anonymous
    from sources import source_catalog
    import bot as botmod
    mgr = request.app["mgr"]
    eng = request.app["engine"]
    c = db.counts()
    tok = db.cfg("bot_token") or ""
    cat = source_catalog()
    states = {s["key"]: s for s in db.src_all()}
    srcs = []
    for s in cat:
        st = states.get(s["key"], {})
        srcs.append(dict(key=s["key"], sat=s["sat"], kind=s["kind"], region=list(s["region"]),
                         enabled=st.get("enabled", 1), fails=st.get("fails", 0),
                         last_ok=st.get("last_ok"), last_new=st.get("last_new"),
                         total_new=st.get("total_new", 0), avg_ms=st.get("avg_ms", 0),
                         last_err=st.get("last_err")))
    recent = [dict(id=r["id"], src=r["src"], sat=r["sat"], kind=r["kind"], fetched_at=r["fetched_at"])
              for r in db.latest_media(12)]
    base.update({
        "csrf": _csrf_for(request.cookies.get("sw_session")),
        "running": mgr.running, "bot_username": db.cfg("bot_username"),
        "sent_total": mgr.sent_total, "last_error": mgr.last_error,
        "public": db.flag("public"), "video": config.ENABLE_VIDEO,
        "users": c["u"], "images": c["i"], "videos": c["v"], "partial": c["p"],
        "last24": c["last24"], "disk": db.disk_usage(), "ram_mb": botmod._rss_mb(),
        "uptime": time.time() - botmod.START_TS, "interval": config.POLL_INTERVAL,
        "round_ms": eng.round_ms if eng else 0, "engine_alive": eng.alive() if eng else False,
        "engine": eng.health() if eng else {},
        "token_masked": (tok[:6] + "…" + tok[-4:]) if tok else "", "admin_id": db.cfg("admin_id"),
        "sources": srcs, "recent": recent, "events": db.events(40),
    })
    return web.json_response(base)


@need_auth
async def bot_ctl(request):
    data = await _json(request)
    mgr = request.app["mgr"]
    try:
        a = data.get("action")
        if a == "start":
            ok = await mgr.start()
        elif a == "restart":
            ok = await mgr.restart()
        else:
            await mgr.stop()
            ok = True
        db.event("info", f"bot {a} via panel")
        return web.json_response({"ok": ok})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)[:120]})


@need_auth
async def public_ctl(request):
    cur = db.flag("public")
    db.setcfg("public", "0" if cur else "1")
    db.event("info", f"public mode -> {not cur}")
    return web.json_response({"ok": True, "public": not cur})


@need_auth
async def video_ctl(request):
    config.ENABLE_VIDEO = not config.ENABLE_VIDEO
    db.setcfg("enable_video", "1" if config.ENABLE_VIDEO else "0")
    return web.json_response({"ok": True, "video": config.ENABLE_VIDEO})


@need_auth
async def broadcast_ctl(request):
    mgr = request.app["mgr"]
    if not mgr.running:
        return web.json_response({"ok": False, "error": "bot stopped"})
    data = await _json(request)
    text = (data.get("text") or "").strip()
    if not text:
        return web.json_response({"ok": False, "error": "empty"})
    n = await broadcast_text(mgr.app.bot, text)
    return web.json_response({"ok": True, "sent": n})


@need_auth
async def settings_ctl(request):
    data = await _json(request)
    iv = int(data.get("interval") or 0)
    if iv:
        if not 15 <= iv <= 600:
            return web.json_response({"ok": False, "error": "interval 15..600"})
        config.POLL_INTERVAL = iv
        db.setcfg("poll_interval", iv)
    pw = data.get("password") or ""
    if pw:
        if len(pw) < 8:
            return web.json_response({"ok": False, "error": "password min 8"})
        db.setcfg("admin_pw", hash_pw(pw))
        db.sessions_clear()
        tok = db.session_create(_ip(request))
        resp = web.json_response({"ok": True, "csrf": _csrf_for(tok)})
        _set_cookie(resp, tok)
        return resp
    return web.json_response({"ok": True})


@need_auth
async def source_ctl(request):
    from sources import ALL_KEYS
    data = await _json(request)
    key = data.get("key")
    if key not in ALL_KEYS:
        return web.json_response({"ok": False, "error": "unknown source"})
    db.src_set_enabled(key, bool(data.get("enabled")))
    return web.json_response({"ok": True})


async def thumb(request):
    if not _authed(request):
        raise web.HTTPUnauthorized()
    try:
        m = db.get_media(int(request.match_info["id"]))
    except ValueError:
        raise web.HTTPNotFound()
    if not m:
        raise web.HTTPNotFound()
    p = m["thumb_path"] if m["thumb_path"] and os.path.exists(m["thumb_path"]) else \
        (m["repaired_path"] if m["kind"] == "image" and m["repaired_path"] and
         os.path.exists(m["repaired_path"]) else m["path"])
    if m["kind"] == "video" and p == m["path"]:
        raise web.HTTPNotFound()
    if not os.path.exists(p):
        raise web.HTTPNotFound()
    return web.FileResponse(p, headers={"Cache-Control": "private, max-age=3600"})


async def media(request):
    if not _authed(request):
        raise web.HTTPUnauthorized()
    try:
        m = db.get_media(int(request.match_info["id"]))
    except ValueError:
        raise web.HTTPNotFound()
    if not m or not os.path.exists(m["path"]):
        raise web.HTTPNotFound()
    return web.FileResponse(m["path"], headers={"Cache-Control": "private, max-age=3600"})


def make_app(mgr, engine=None):
    app = web.Application(middlewares=[sec_mw], client_max_size=256 * 1024)
    app["mgr"] = mgr
    app["engine"] = engine
    r = app.router
    r.add_get("/", index)
    r.add_get("/health", lambda req: web.json_response({"ok": True, "bot": mgr.running}))
    r.add_post("/setup", setup)
    r.add_post("/api/check_token", check_token)
    r.add_post("/api/login", login)
    r.add_post("/api/logout", logout)
    r.add_get("/api/state", state)
    r.add_post("/api/bot", bot_ctl)
    r.add_post("/api/public", public_ctl)
    r.add_post("/api/video", video_ctl)
    r.add_post("/api/broadcast", broadcast_ctl)
    r.add_post("/api/settings", settings_ctl)
    r.add_post("/api/source", source_ctl)
    r.add_get("/thumb/{id}", thumb)
    r.add_get("/media/{id}", media)
    return app
