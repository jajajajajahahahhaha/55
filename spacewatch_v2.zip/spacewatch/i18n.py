"""UI strings — 10 languages. Fallback: lang -> en -> key."""

LANGS = [
    ("fa", "فارسی", "🇮🇷"), ("en", "English", "🇬🇧"), ("ar", "العربية", "🇸🇦"),
    ("tr", "Türkçe", "🇹🇷"), ("ru", "Русский", "🇷🇺"), ("zh", "中文", "🇨🇳"),
    ("es", "Español", "🇪🇸"), ("fr", "Français", "🇫🇷"), ("de", "Deutsch", "🇩🇪"),
    ("ja", "日本語", "🇯🇵"),
]
RTL = {"fa", "ar"}

T = {
"fa": {
 "choose_lang": "🌐 زبان خود را انتخاب کنید:",
 "lang_saved": "✅ زبان ذخیره شد: فارسی",
 "welcome": ("سلام! 👋 به «رصد فضا» خوش اومدی.\n\n"
             "از این لحظه جدیدترین تصاویر و ویدیوهای ماهواره‌ها و تلسکوپ‌های فضایی — "
             "به‌محض انتشار از منابع رسمی (NOAA، EUMETSAT، NASA، ESA، JMA، CMA) — همین‌جا برات میاد. 🛰️\n\n"
             "🇮🇷 پوشش ویژه ایران و خاورمیانه با Meteosat-9 و Meteosat-12.\n"
             "برای دیدن راهنما /help رو بزن."),
 "help": ("🛰️ <b>راهنمای بات رصد فضا</b>\n\n"
          "بات هر ۳۰ ثانیه ۵۰+ منبع رسمی رو موازی چک می‌کنه و هر تصویر/ویدیوی جدید رو "
          "با زمان دقیق تصویربرداری، منطقه و ماهواره می‌فرسته.\n\n"
          "📌 <b>دستورها</b>\n"
          "/latest — آخرین تصویر هر گروه (ایران، زمین، خورشید، فضای عمیق)\n"
          "/iran — آخرین تصویر ایران و خلیج فارس 🇮🇷\n"
          "/region &lt;نام&gt; — آخرین تصویر یک کشور/منطقه (مثال: /region iran)\n"
          "/history 6H — تصاویر ۶ ساعت گذشته (M=دقیقه، H=ساعت، D=روز)\n"
          "/video — آخرین ویدیوها 🎬\n"
          "/sources — لیست منابع و وضعیت هرکدام\n"
          "/status — وضعیت بات، تاخیر، حافظه\n"
          "/mute /unmute — قطع/وصل ارسال خودکار برای شما\n"
          "/novideo /yesvideo — دریافت ویدیو خاموش/روشن\n"
          "/lang — تغییر زبان\n\n"
          "👑 <b>ادمین</b>\n"
          "/all — همه تصاویر در یک ZIP\n"
          "/public — روشن/خاموش ارسال برای همه کاربران\n"
          "/broadcast متن — پیام همگانی\n"
          "/source &lt;key&gt; on|off — فعال/غیرفعال کردن یک منبع\n\n"
          "⚙️ <b>نکات</b>\n"
          "• تصاویر تکراری هرگز ارسال نمی‌شن (هش محتوا).\n"
          "• «تأخیر» = فاصله زمان تصویربرداری تا دریافت بات؛ بعضی منابع (مثل DSCOVR) ذاتاً ۱–۲ روز تأخیر دارن.\n"
          "• تصاویر ناقص فوراً میان، بعد نسخه ترمیم‌شده (OpenCV) و نسخه کامل.\n"
          "• عکس‌های بسیار بزرگ به‌صورت پیش‌نمایش + فایل اصلی (دکمه 🔗) میان.\n"
          "• فایل‌های +۴۹MB با لینک دانلود مستقیم موقت."),
 "cap_title": "تصویر جدید", "cap_video": "ویدیوی جدید",
 "region": "منطقه", "time": "زمان تصویربرداری", "delay": "تأخیر دریافت",
 "sat": "ماهواره", "quality": "کیفیت", "size": "حجم", "status": "وضعیت",
 "duration": "مدت", "source_key": "کلید منبع",
 "st_complete": "✅ کامل", "st_partial": "⚠️ ناقص (نسخه کامل بعداً می‌آید)",
 "min": "دقیقه", "sec": "ثانیه", "hour": "ساعت", "day": "روز",
 "hist_none": "📭 در این بازه تصویری ثبت نشده.",
 "hist_usage": "مثال: /history 6H یا /history 2D یا /history 30M",
 "hist_cap": "📚 {n} مورد در {span} گذشته (حداکثر {max} تا ارسال می‌شود):",
 "uptime_less": "ℹ️ بات فقط {have} فعال بوده و هنوز به‌اندازه بازه درخواستی کار نکرده؛ این موارد موجود است:",
 "region_none": "📭 تصویری برای این منطقه پیدا نشد. با /sources ببین کدوم منابع فعال‌اند.",
 "region_usage": "مثال: /region iran یا /region japan یا /region sun",
 "admin_only": "⛔ این دستور فقط برای ادمین است.",
 "all_wait": "⏳ در حال ساخت فایل ZIP از تصاویر ۲۴ ساعت گذشته...",
 "all_big": "📦 حجم فایل بیش از ۴۹ مگابایت است؛ لینک دانلود مستقیم موقت:",
 "no_tunnel": "⚠️ لینک دانلود در دسترس نیست (cloudflared نصب نیست)؛ فایل روی سرور ذخیره شد.",
 "public_on": "🌍 حالت عمومی روشن شد — تصاویر برای همه کاربران ارسال می‌شود.",
 "public_off": "🔒 حالت عمومی خاموش شد — فقط ادمین دریافت می‌کند.",
 "broadcast_done": "📣 پیام برای {n} کاربر ارسال شد.",
 "orig_btn": "🔗 فایل اصلی", "rep_btn": "🛠 ترمیم‌شده", "info_btn": "ℹ️ جزئیات",
 "more_btn": "🛰 بیشتر از این منبع",
 "no_repaired": "نسخه ترمیم‌شده برای این تصویر موجود نیست.",
 "completed_follow": "✅ نسخه کاملِ تصویر ناقص قبلی رسید",
 "repaired_caption": "🛠 نسخه ترمیم‌شده خودکار (OpenCV)",
 "muted": "🔕 ارسال خودکار برای شما خاموش شد. با /unmute دوباره روشن کن.",
 "unmuted": "🔔 ارسال خودکار روشن شد.",
 "video_off": "🎬 دریافت ویدیو خاموش شد.", "video_on": "🎬 دریافت ویدیو روشن شد.",
 "no_video": "📭 هنوز ویدیویی دریافت نشده.",
 "latest_title": "🆕 <b>آخرین تصاویر هر گروه</b>",
 "nothing_yet": "⏳ بات تازه شروع کرده و هنوز تصویری نگرفته؛ چند دقیقه دیگه دوباره بزن.",
 "status_tpl": ("📊 <b>وضعیت بات</b>\n"
                "⏱ آپتایم: {up}\n🔁 دورهای چک: {rounds} (آخرین دور {round_ms} ms)\n"
                "🖼 تصاویر: {images}  🎬 ویدیو: {videos}  ⚠️ ناقص: {partial}\n"
                "📥 ۲۴ ساعت گذشته: {last24} مورد\n"
                "👥 کاربران: {users}\n💾 دیسک: {disk} MB  🧠 RAM: {mem} MB\n"
                "📡 منابع: {ok} سالم / {bad} خطا / {off} غیرفعال\n"
                "🌍 حالت عمومی: {public}"),
 "sources_title": "📡 <b>منابع ({n})</b>\n<i>✅ سالم • ⚠️ خطا/بک‌آف • ⛔ غیرفعال — زمان = آخرین مورد جدید</i>",
 "src_toggled": "✅ منبع {key} → {state}",
 "src_unknown": "❓ منبع ناشناخته. با /sources لیست رو ببین.",
 "on": "روشن", "off": "خاموش", "never": "هنوز هیچ",
 "ago": "پیش",
 "big_preview": "🔍 پیش‌نمایش — فایل اصلی {w}×{h} ({mb} MB) با دکمه 🔗",
 "yes": "بله", "no": "خیر",
},
"en": {
 "choose_lang": "🌐 Choose your language:",
 "lang_saved": "✅ Language saved: English",
 "welcome": ("Hi! 👋 Welcome to SpaceWatch.\n\n"
             "From now on the newest satellite & space-telescope images and videos arrive here the "
             "moment they're published by official sources (NOAA, EUMETSAT, NASA, ESA, JMA, CMA). 🛰️\n\n"
             "Special coverage of Iran & the Middle East via Meteosat-9 / Meteosat-12.\nSend /help for commands."),
 "help": ("🛰️ <b>SpaceWatch Help</b>\n\n"
          "Every 30 s the bot checks 50+ official sources in parallel and forwards every new "
          "image/video with exact capture time, region and satellite.\n\n"
          "📌 <b>Commands</b>\n"
          "/latest — newest image of each group\n"
          "/iran — latest Iran / Persian Gulf image 🇮🇷\n"
          "/region &lt;name&gt; — latest image of a country/region\n"
          "/history 6H — last 6 hours (M/H/D)\n"
          "/video — latest videos 🎬\n"
          "/sources — source list & health\n"
          "/status — bot status, delay, memory\n"
          "/mute /unmute — pause/resume auto delivery\n"
          "/novideo /yesvideo — video delivery off/on\n"
          "/lang — change language\n\n"
          "👑 <b>Admin</b>\n/all — ZIP of all images\n/public — toggle public delivery\n"
          "/broadcast text — message everyone\n/source &lt;key&gt; on|off — enable/disable a source\n\n"
          "⚙️ Duplicates are never sent (content hash) • “Delay” = capture→fetch; some sources (DSCOVR) "
          "are inherently 1–2 days late • partial images arrive instantly, then repaired & complete • "
          "huge images come as preview + original (🔗) • files >49 MB as a temporary direct link."),
 "cap_title": "New image", "cap_video": "New video",
 "region": "Region", "time": "Capture time", "delay": "Fetch delay",
 "sat": "Satellite", "quality": "Quality", "size": "Size", "status": "Status",
 "duration": "Duration", "source_key": "Source key",
 "st_complete": "✅ Complete", "st_partial": "⚠️ Partial (complete version follows)",
 "min": "min", "sec": "s", "hour": "h", "day": "d",
 "hist_none": "📭 No images in this window.",
 "hist_usage": "Example: /history 6H or /history 2D or /history 30M",
 "hist_cap": "📚 {n} items in the last {span} (sending up to {max}):",
 "uptime_less": "ℹ️ The bot has only been up for {have}; here's everything so far:",
 "region_none": "📭 No image found for that region. See /sources.",
 "region_usage": "Example: /region iran or /region japan or /region sun",
 "admin_only": "⛔ Admin only.",
 "all_wait": "⏳ Building a ZIP of the last 24 h...",
 "all_big": "📦 File exceeds 49 MB; temporary direct-download link:",
 "no_tunnel": "⚠️ Download link unavailable (cloudflared not installed); file stored on the server.",
 "public_on": "🌍 Public mode ON — images go to all users.",
 "public_off": "🔒 Public mode OFF — admin only.",
 "broadcast_done": "📣 Sent to {n} users.",
 "orig_btn": "🔗 Original", "rep_btn": "🛠 Repaired", "info_btn": "ℹ️ Details",
 "more_btn": "🛰 More from source",
 "no_repaired": "No repaired version for this image.",
 "completed_follow": "✅ Complete version of the earlier partial image",
 "repaired_caption": "🛠 Auto-repaired version (OpenCV)",
 "muted": "🔕 Auto delivery paused. /unmute to resume.", "unmuted": "🔔 Auto delivery resumed.",
 "video_off": "🎬 Video delivery off.", "video_on": "🎬 Video delivery on.",
 "no_video": "📭 No videos yet.",
 "latest_title": "🆕 <b>Latest per group</b>",
 "nothing_yet": "⏳ The bot just started and has no images yet; try again in a few minutes.",
 "status_tpl": ("📊 <b>Bot status</b>\n⏱ Uptime: {up}\n🔁 Poll rounds: {rounds} (last {round_ms} ms)\n"
                "🖼 Images: {images}  🎬 Videos: {videos}  ⚠️ Partial: {partial}\n📥 Last 24 h: {last24}\n"
                "👥 Users: {users}\n💾 Disk: {disk} MB  🧠 RAM: {mem} MB\n"
                "📡 Sources: {ok} ok / {bad} failing / {off} disabled\n🌍 Public: {public}"),
 "sources_title": "📡 <b>Sources ({n})</b>\n<i>✅ ok • ⚠️ error/back-off • ⛔ disabled — time = last new item</i>",
 "src_toggled": "✅ Source {key} → {state}", "src_unknown": "❓ Unknown source. See /sources.",
 "on": "on", "off": "off", "never": "never", "ago": "ago",
 "big_preview": "🔍 Preview — original {w}×{h} ({mb} MB) via 🔗",
 "yes": "yes", "no": "no",
},
"ar": {
 "lang_saved": "✅ تم حفظ اللغة: العربية",
 "welcome": "مرحباً! 👋 أحدث صور ومقاطع الأقمار الصناعية والتلسكوبات الفضائية تصلك فور نشرها. 🛰️\nتغطية خاصة للشرق الأوسط عبر Meteosat.",
 "help": "🛰️ الأوامر:\n/latest أحدث صورة لكل مجموعة\n/iran إيران والخليج\n/region <اسم> صورة منطقة\n/history 6H آخر ٦ ساعات\n/video أحدث المقاطع\n/sources المصادر\n/status الحالة\n/mute /unmute إيقاف/تشغيل\n/lang اللغة",
 "cap_title": "صورة جديدة", "cap_video": "مقطع جديد", "region": "المنطقة", "time": "وقت الالتقاط", "delay": "التأخير",
 "sat": "القمر الصناعي", "quality": "الجودة", "size": "الحجم", "status": "الحالة", "duration": "المدة",
 "st_complete": "✅ كاملة", "st_partial": "⚠️ ناقصة", "min": "دقيقة", "sec": "ثانية", "hour": "س", "day": "ي",
 "hist_none": "📭 لا صور.", "uptime_less": "ℹ️ البوت يعمل منذ {have} فقط:",
 "region_none": "📭 لا توجد صورة لهذه المنطقة.", "admin_only": "⛔ للمشرف فقط.",
 "all_wait": "⏳ جارٍ إنشاء ZIP...", "all_big": "📦 الملف أكبر من 49MB، رابط التحميل:",
 "broadcast_done": "📣 أُرسلت إلى {n}.", "orig_btn": "🔗 الأصل", "rep_btn": "🛠 المرمّمة", "info_btn": "ℹ️ تفاصيل",
 "more_btn": "🛰 المزيد", "completed_follow": "✅ وصلت النسخة الكاملة", "repaired_caption": "🛠 نسخة مرمّمة تلقائياً",
 "muted": "🔕 تم الإيقاف.", "unmuted": "🔔 تم التشغيل.", "no_video": "📭 لا مقاطع بعد.", "nothing_yet": "⏳ لا صور بعد.",
},
"tr": {
 "lang_saved": "✅ Dil kaydedildi: Türkçe",
 "welcome": "Merhaba! 👋 En yeni uydu ve uzay teleskobu görüntüleri/videoları yayınlanır yayınlanmaz burada. 🛰️",
 "help": "🛰️ Komutlar:\n/latest her grubun son görüntüsü\n/iran İran & Körfez\n/region <ad> bölge\n/history 6H son 6 saat\n/video videolar\n/sources kaynaklar\n/status durum\n/mute /unmute\n/lang dil",
 "cap_title": "Yeni görüntü", "cap_video": "Yeni video", "region": "Bölge", "time": "Çekim zamanı", "delay": "Gecikme",
 "sat": "Uydu", "quality": "Kalite", "size": "Boyut", "status": "Durum", "duration": "Süre",
 "st_complete": "✅ Tam", "st_partial": "⚠️ Eksik", "min": "dk", "sec": "sn", "hour": "sa", "day": "g",
 "hist_none": "📭 Görüntü yok.", "uptime_less": "ℹ️ Bot yalnızca {have} çalışıyor:",
 "region_none": "📭 Bu bölge için görüntü yok.", "admin_only": "⛔ Yalnızca yönetici.",
 "all_wait": "⏳ ZIP hazırlanıyor...", "all_big": "📦 Dosya 49MB üstü, indirme bağlantısı:",
 "broadcast_done": "📣 {n} kullanıcıya gönderildi.", "orig_btn": "🔗 Orijinal", "rep_btn": "🛠 Onarılmış", "info_btn": "ℹ️ Detay",
 "more_btn": "🛰 Daha fazla", "completed_follow": "✅ Tam sürüm geldi", "repaired_caption": "🛠 Otomatik onarılmış",
 "muted": "🔕 Duraklatıldı.", "unmuted": "🔔 Devam.", "no_video": "📭 Henüz video yok.", "nothing_yet": "⏳ Henüz görüntü yok.",
},
"ru": {
 "lang_saved": "✅ Язык сохранён: русский",
 "welcome": "Привет! 👋 Новейшие снимки и видео спутников и космических телескопов — сразу после публикации. 🛰️",
 "help": "🛰️ Команды:\n/latest последний снимок каждой группы\n/iran Иран и Персидский залив\n/region <имя> регион\n/history 6H за 6 часов\n/video видео\n/sources источники\n/status статус\n/mute /unmute\n/lang язык",
 "cap_title": "Новый снимок", "cap_video": "Новое видео", "region": "Регион", "time": "Время съёмки", "delay": "Задержка",
 "sat": "Спутник", "quality": "Качество", "size": "Размер", "status": "Статус", "duration": "Длительность",
 "st_complete": "✅ Полный", "st_partial": "⚠️ Частичный", "min": "мин", "sec": "с", "hour": "ч", "day": "д",
 "hist_none": "📭 Нет снимков.", "uptime_less": "ℹ️ Бот работает только {have}:",
 "region_none": "📭 Снимок региона не найден.", "admin_only": "⛔ Только админ.",
 "all_wait": "⏳ Создаю ZIP...", "all_big": "📦 Файл больше 49МБ, ссылка:",
 "broadcast_done": "📣 Отправлено {n} пользователям.", "orig_btn": "🔗 Оригинал", "rep_btn": "🛠 Восстановл.", "info_btn": "ℹ️ Детали",
 "more_btn": "🛰 Ещё", "completed_follow": "✅ Полная версия получена", "repaired_caption": "🛠 Автовосстановленная версия",
 "muted": "🔕 Пауза.", "unmuted": "🔔 Возобновлено.", "no_video": "📭 Видео пока нет.", "nothing_yet": "⏳ Снимков пока нет.",
},
"zh": {
 "lang_saved": "✅ 语言已保存：中文",
 "welcome": "你好！👋 最新的卫星与太空望远镜图像和视频一经发布就会推送到这里。🛰️",
 "help": "🛰️ 命令：\n/latest 各组最新图像\n/iran 伊朗与海湾\n/region <名称> 地区\n/history 6H 最近6小时\n/video 视频\n/sources 数据源\n/status 状态\n/mute /unmute\n/lang 语言",
 "cap_title": "新图像", "cap_video": "新视频", "region": "区域", "time": "拍摄时间", "delay": "延迟",
 "sat": "卫星", "quality": "质量", "size": "大小", "status": "状态", "duration": "时长",
 "st_complete": "✅ 完整", "st_partial": "⚠️ 不完整", "min": "分", "sec": "秒", "hour": "时", "day": "天",
 "hist_none": "📭 暂无图像。", "uptime_less": "ℹ️ 机器人仅运行了 {have}：",
 "region_none": "📭 未找到该区域图像。", "admin_only": "⛔ 仅限管理员。",
 "all_wait": "⏳ 正在打包 ZIP...", "all_big": "📦 文件超过49MB，下载链接：",
 "broadcast_done": "📣 已发送给 {n} 位用户。", "orig_btn": "🔗 原图", "rep_btn": "🛠 修复版", "info_btn": "ℹ️ 详情",
 "more_btn": "🛰 更多", "completed_follow": "✅ 完整版本已到达", "repaired_caption": "🛠 自动修复版本",
 "muted": "🔕 已暂停。", "unmuted": "🔔 已恢复。", "no_video": "📭 暂无视频。", "nothing_yet": "⏳ 暂无图像。",
},
"es": {
 "lang_saved": "✅ Idioma guardado: español",
 "welcome": "¡Hola! 👋 Las imágenes y vídeos más recientes de satélites y telescopios espaciales llegan aquí al publicarse. 🛰️",
 "help": "🛰️ Comandos:\n/latest última imagen por grupo\n/iran Irán y Golfo\n/region <nombre> región\n/history 6H últimas 6 h\n/video vídeos\n/sources fuentes\n/status estado\n/mute /unmute\n/lang idioma",
 "cap_title": "Nueva imagen", "cap_video": "Nuevo vídeo", "region": "Región", "time": "Hora de captura", "delay": "Retraso",
 "sat": "Satélite", "quality": "Calidad", "size": "Tamaño", "status": "Estado", "duration": "Duración",
 "st_complete": "✅ Completa", "st_partial": "⚠️ Parcial", "min": "min", "sec": "s", "hour": "h", "day": "d",
 "hist_none": "📭 Sin imágenes.", "uptime_less": "ℹ️ El bot solo lleva {have} activo:",
 "region_none": "📭 Sin imagen de esa región.", "admin_only": "⛔ Solo admin.",
 "all_wait": "⏳ Creando ZIP...", "all_big": "📦 Archivo >49MB, enlace de descarga:",
 "broadcast_done": "📣 Enviado a {n} usuarios.", "orig_btn": "🔗 Original", "rep_btn": "🛠 Reparada", "info_btn": "ℹ️ Detalles",
 "more_btn": "🛰 Más", "completed_follow": "✅ Versión completa recibida", "repaired_caption": "🛠 Versión reparada",
 "muted": "🔕 Pausado.", "unmuted": "🔔 Reanudado.", "no_video": "📭 Sin vídeos aún.", "nothing_yet": "⏳ Sin imágenes aún.",
},
"fr": {
 "lang_saved": "✅ Langue enregistrée : français",
 "welcome": "Salut ! 👋 Les dernières images et vidéos satellites/télescopes arrivent ici dès publication. 🛰️",
 "help": "🛰️ Commandes :\n/latest dernière image par groupe\n/iran Iran & Golfe\n/region <nom> région\n/history 6H 6 dernières heures\n/video vidéos\n/sources sources\n/status état\n/mute /unmute\n/lang langue",
 "cap_title": "Nouvelle image", "cap_video": "Nouvelle vidéo", "region": "Région", "time": "Heure de capture", "delay": "Délai",
 "sat": "Satellite", "quality": "Qualité", "size": "Taille", "status": "Statut", "duration": "Durée",
 "st_complete": "✅ Complète", "st_partial": "⚠️ Partielle", "min": "min", "sec": "s", "hour": "h", "day": "j",
 "hist_none": "📭 Aucune image.", "uptime_less": "ℹ️ Le bot n'est actif que depuis {have} :",
 "region_none": "📭 Aucune image pour cette région.", "admin_only": "⛔ Admin uniquement.",
 "all_wait": "⏳ Création du ZIP...", "all_big": "📦 Fichier >49Mo, lien :",
 "broadcast_done": "📣 Envoyé à {n} utilisateurs.", "orig_btn": "🔗 Original", "rep_btn": "🛠 Réparée", "info_btn": "ℹ️ Détails",
 "more_btn": "🛰 Plus", "completed_follow": "✅ Version complète reçue", "repaired_caption": "🛠 Version réparée auto",
 "muted": "🔕 En pause.", "unmuted": "🔔 Repris.", "no_video": "📭 Pas encore de vidéo.", "nothing_yet": "⏳ Pas encore d'image.",
},
"de": {
 "lang_saved": "✅ Sprache gespeichert: Deutsch",
 "welcome": "Hallo! 👋 Die neuesten Satelliten- und Teleskop-Bilder/Videos kommen hier sofort nach Veröffentlichung an. 🛰️",
 "help": "🛰️ Befehle:\n/latest neuestes Bild je Gruppe\n/iran Iran & Golf\n/region <Name> Region\n/history 6H letzte 6 h\n/video Videos\n/sources Quellen\n/status Status\n/mute /unmute\n/lang Sprache",
 "cap_title": "Neues Bild", "cap_video": "Neues Video", "region": "Region", "time": "Aufnahmezeit", "delay": "Verzögerung",
 "sat": "Satellit", "quality": "Qualität", "size": "Größe", "status": "Status", "duration": "Dauer",
 "st_complete": "✅ Vollständig", "st_partial": "⚠️ Unvollständig", "min": "Min", "sec": "s", "hour": "h", "day": "T",
 "hist_none": "📭 Keine Bilder.", "uptime_less": "ℹ️ Der Bot läuft erst {have}:",
 "region_none": "📭 Kein Bild für diese Region.", "admin_only": "⛔ Nur Admin.",
 "all_wait": "⏳ ZIP wird erstellt...", "all_big": "📦 Datei >49MB, Download-Link:",
 "broadcast_done": "📣 An {n} Nutzer gesendet.", "orig_btn": "🔗 Original", "rep_btn": "🛠 Repariert", "info_btn": "ℹ️ Details",
 "more_btn": "🛰 Mehr", "completed_follow": "✅ Vollständige Version eingetroffen", "repaired_caption": "🛠 Auto-repariert",
 "muted": "🔕 Pausiert.", "unmuted": "🔔 Fortgesetzt.", "no_video": "📭 Noch keine Videos.", "nothing_yet": "⏳ Noch keine Bilder.",
},
"ja": {
 "lang_saved": "✅ 言語を保存しました：日本語",
 "welcome": "こんにちは！👋 衛星・宇宙望遠鏡の最新画像と動画が公開され次第ここに届きます。🛰️",
 "help": "🛰️ コマンド：\n/latest 各グループの最新画像\n/iran イラン・湾岸\n/region <名前> 地域\n/history 6H 過去6時間\n/video 動画\n/sources ソース\n/status 状態\n/mute /unmute\n/lang 言語",
 "cap_title": "新しい画像", "cap_video": "新しい動画", "region": "地域", "time": "撮影時刻", "delay": "遅延",
 "sat": "衛星", "quality": "品質", "size": "サイズ", "status": "状態", "duration": "長さ",
 "st_complete": "✅ 完全", "st_partial": "⚠️ 不完全", "min": "分", "sec": "秒", "hour": "時間", "day": "日",
 "hist_none": "📭 画像がありません。", "uptime_less": "ℹ️ 稼働時間は {have} のみ：",
 "region_none": "📭 その地域の画像がありません。", "admin_only": "⛔ 管理者のみ。",
 "all_wait": "⏳ ZIP作成中...", "all_big": "📦 49MB超のためダウンロードリンク：",
 "broadcast_done": "📣 {n}人に送信しました。", "orig_btn": "🔗 原本", "rep_btn": "🛠 修復版", "info_btn": "ℹ️ 詳細",
 "more_btn": "🛰 もっと", "completed_follow": "✅ 完全版が届きました", "repaired_caption": "🛠 自動修復バージョン",
 "muted": "🔕 一時停止。", "unmuted": "🔔 再開。", "no_video": "📭 動画はまだありません。", "nothing_yet": "⏳ 画像はまだありません。",
},
}


def tr(lang, key):
    return T.get(lang, {}).get(key) or T["en"].get(key) or key
