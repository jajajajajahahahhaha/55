"""Offline + live debug test-suite for SpaceWatch v2.  Run: python test_run.py [--live]"""
import asyncio
import os
import shutil
import sys
import tempfile
import time

TMP = tempfile.mkdtemp(prefix="swtest_")
os.environ["SW_DATA_DIR"] = TMP
import config  # noqa: E402

config.DATA_DIR = TMP
config.IMG_DIR = os.path.join(TMP, "images")
config.VID_DIR = os.path.join(TMP, "videos")
config.FILE_DIR = os.path.join(TMP, "files")
config.DB_PATH = os.path.join(TMP, "bot.db")
config.LOG_PATH = os.path.join(TMP, "bot.log")

PASS, FAIL = 0, 0
LIVE = "--live" in sys.argv


def check(name, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✅ {name}")
    else:
        FAIL += 1
        print(f"  ❌ {name}")


print("== 1) imports ==")
try:
    import database as db
    import repair
    import i18n
    import sources
    import tunnel
    import webui
    import bot
    import main  # noqa
    check("all modules import", True)
except Exception as e:
    import traceback
    traceback.print_exc()
    check(f"all modules import ({e})", False)
    sys.exit(1)

print("== 2) database ==")
db.init()
db.setcfg("bot_token", "x")
check("cfg set/get", db.cfg("bot_token") == "x")
db.ensure_user(123)
db.set_user_lang(123, "en")
check("user lang", db.get_user_lang(123) == "en")
db.set_user_flag(123, "muted", True)
check("mute flag", db.get_user(123)["muted"] == 1 and len(db.get_users()) == 0)
db.set_user_flag(123, "muted", False)
mid = db.insert_media(dict(src="iodc_iran_natural", url="http://x", hash="h1", path="/tmp/a.jpg",
                           region="ایران و خاورمیانه", region_en="Iran & Middle East", cc="IR",
                           lat=32.0, lon=53.0, sat="Meteosat-9", img_time=100.0,
                           fetched_at=1000.0, status="complete", width=10, height=10, size=100))
check("insert + exists", db.media_exists("h1"))
check("get_media", db.get_media(mid)["sat"] == "Meteosat-9")
check("find_region iran", db.find_region("iran")[0]["id"] == mid)
check("find_region IR", db.find_region("IR")[0]["id"] == mid)
check("find_region me", db.find_region("me")[0]["id"] == mid)
vid = db.insert_media(dict(src="v_sdo_193", url="http://v", hash="h2", path="/tmp/b.mp4", kind="video",
                           region="خورشید", region_en="Sun", sat="SDO", img_time=time.time(),
                           fetched_at=time.time(), width=512, height=512, size=1, duration=19.3))
check("latest video", db.latest_media(1, kind="video")[0]["id"] == vid)
c = db.counts()
check("counts", (c["u"], c["i"], c["v"]) == (1, 1, 1))
db.src_fail("goes19_fd", "boom")
st = db.src_state("goes19_fd")
check("source backoff", st["fails"] == 1 and st["next_try"] > time.time())
db.src_ok("goes19_fd", etag='"abc"', ms=120, new_item=True)
st = db.src_state("goes19_fd")
check("source ok resets", st["fails"] == 0 and st["etag"] == '"abc"' and st["total_new"] == 1)
tok = db.session_create("1.2.3.4")
check("session valid", db.session_valid(tok) and not db.session_valid("nope"))
db.session_drop(tok)
check("session drop", not db.session_valid(tok))
db.event("info", "hello")
check("events", db.events(1)[0]["msg"] == "hello")

print("== 3) repair (OpenCV) ==")
import cv2
import numpy as np
ok_img = np.random.randint(0, 255, (300, 300, 3), np.uint8)
p_ok = os.path.join(TMP, "ok.jpg")
cv2.imwrite(p_ok, ok_img)
check("complete img not partial", repair.detect_partial(p_ok) is False)
part = np.random.randint(0, 255, (300, 300, 3), np.uint8)
part[220:, :] = 128  # gray trailing band (27%) = partially rendered disk
p_bad = os.path.join(TMP, "bad.jpg")
cv2.imwrite(p_bad, part)
check("partial img detected (visual)", repair.detect_partial(p_bad, True) is True)
rep = repair.try_repair(p_bad)
check("repair output exists", bool(rep) and os.path.exists(rep))
with open(p_ok, "rb") as f:
    full = f.read()
check("byte-level truncation: full ok", repair.is_truncated(full) is False)
check("byte-level truncation: cut detected", repair.is_truncated(full[: len(full) // 2]) is True)
# false-positive guard: sun on black background (natural black edges)
sun = np.zeros((400, 400, 3), np.uint8)
cv2.circle(sun, (200, 200), 120, (30, 90, 230), -1)
noise = np.random.randint(0, 40, (400, 400, 3), np.uint8)
sun = cv2.add(sun, (noise * (sun > 0)).astype(np.uint8))
p_sun = os.path.join(TMP, "sun.jpg")
cv2.imwrite(p_sun, sun)
check("sun on black NOT partial (v1 false positive fixed)", repair.detect_partial(p_sun, True) is False)
blank = np.zeros((200, 200, 3), np.uint8)
p_blank = os.path.join(TMP, "blank.jpg")
cv2.imwrite(p_blank, blank)
check("dark detection", repair.is_dark(p_blank) is True and repair.is_dark(p_ok) is False)
sz = repair.make_preview(p_ok, os.path.join(TMP, "t.jpg"), 100)
check("preview", sz == (100, 100))

print("== 4) i18n ==")
core = ["welcome", "help", "cap_title", "region", "time", "delay", "sat", "quality", "status",
        "orig_btn", "rep_btn", "info_btn", "muted"]
for code, _, _ in i18n.LANGS:
    missing = [k for k in core if not i18n.tr(code, k)]
    check(f"lang {code} core keys", not missing)
check("fa help mentions Iran", "ایران" in i18n.tr("fa", "help") and "/iran" in i18n.tr("fa", "help"))

print("== 5) bot ==")
m = bot.HIST_RE.search("/history 6H")
check("history 6H", m and (m.group(1), m.group(2).lower()) == ("6", "h"))
row = db.get_media(mid)
cap = bot.caption_for(row, "fa")
check("caption fa (bilingual region)", "تصویر جدید" in cap and "ایران" in cap and "Meteosat" in cap)
cap_en = bot.caption_for(row, "en")
check("caption en", "New image" in cap_en and "Iran" in cap_en)
vcap = bot.caption_for(db.get_media(vid), "en")
check("video caption", "New video" in vcap and "Duration" in vcap)
kb = bot.glass_buttons(row, "fa")
check("glass buttons (no repair btn when none)", len(kb.inline_keyboard[0]) == 2)
check("fmt_dur", bot.fmt_dur(3600 * 5 + 120, "en") == "5 h 2 min")
check("flood guard (6/10s)", not bot._flood(1) and all(not bot._flood(1) for _ in range(5)) and bot._flood(1))

print("== 6) sources registry ==")
keys = sources.ALL_KEYS
check(f"{len(keys)} sources registered (>=40)", len(keys) >= 40)
check("unique keys", len(set(keys)) == len(keys))
me = [s for s in sources.SOURCES if s.get("group") == "me"]
check(f"{len(me)} Middle-East/Iran sources (>=6)", len(me) >= 6)
check("IODC/MTG layer used (not FES) for Iran", all(s["layer"].startswith(("msg_iodc", "mtg_fd")) for s in me))
vids = [s for s in sources.SOURCES if s["kind"] == "video"]
check(f"{len(vids)} video sources (>=8)", len(vids) >= 8)
check("region_text", sources.region_text(("الف", "A"), "en") == "A")
cat = sources.source_catalog()
check("catalog complete", len(cat) == len(keys))
check("GOES julian filename time", sources.time_from_name("20262511810_GOES19-ABI-FD") == 1788891000)
check("SUVI filename time", sources.time_from_name("or_suvi_s20260908T184000Z") == 1788892800)
import feedparser
feed_xml = """<?xml version='1.0'?><rss version='2.0'><channel><item>
<title>Test Nebula</title><link>http://x</link>
<description>&lt;img src="https://cdn.example.com/big.jpg"/&gt;</description>
</item></channel></rss>"""
check("feed entry image regex",
      sources._entry_image(feedparser.parse(feed_xml).entries[0]) == "https://cdn.example.com/big.jpg")


async def store_test():
    q = asyncio.Queue()
    eng = sources.Engine(q)
    s = sources.SOURCE_MAP["goes19_fd"]
    with open(p_ok, "rb") as f:
        data = f.read()
    mid1 = await eng.ingest_image(s, data, {}, url="u", img_time=time.time())
    dup = await eng.ingest_image(s, data, {}, url="u")
    old = await eng.ingest_image(s, data + b"\x00", {}, url="u2", img_time=time.time() - 10 * 86400)
    s2 = sources.SOURCE_MAP["iodc_iran_natural"]
    with open(p_blank, "rb") as f:
        bl = await eng.ingest_image(s2, f.read(), {}, url="u3")
    return mid1, dup, old, bl, q.qsize()

mid1, dup, old, bl, qn = asyncio.run(store_test())
check("ingest_image ok", bool(mid1))
check("dedup by hash", dup is None)
check("old item archived, NOT queued", old and qn == 1)
check("dark (night) WMS render skipped", bl is None)

print("== 7) webui ==")
h = webui.hash_pw("secret123")
check("pbkdf2 hash/verify", webui.check_pw("secret123", h) and not webui.check_pw("bad", h))


class _Mgr:
    running = False
    sent_total = 0
    last_error = None
    queue = asyncio.Queue()


app = webui.make_app(_Mgr(), sources.Engine(asyncio.Queue()))
check("webui routes", len(app.router.routes()) >= 14)
check("html: patch-in-place render", "function patch(" in webui.HTML and "textContent" in webui.HTML)
check("html: password + csrf + token check", all(k in webui.HTML for k in
                                                ("X-CSRF", "check_token", "togglePw")))


async def web_test():
    from aiohttp.test_utils import TestClient, TestServer
    async with TestClient(TestServer(app)) as c:
        r = await c.get("/api/state")
        j = await r.json()
        check("anon state leaks nothing", set(j) == {"configured", "admin"})
        r = await c.post("/api/bot", json={"action": "start"})
        check("anon POST -> 401", r.status == 401)
        db.delcfg("bot_token")
        r = await c.post("/setup", json={"token": "1:x", "admin_id": "12", "password": "short"})
        check("setup rejects short pw", (await r.json())["ok"] is False)
        db.setcfg("bot_token", "x")
        db.setcfg("admin_pw", webui.hash_pw("secret123"))
        r = await c.post("/api/login", json={"password": "wrong"})
        check("login wrong pw", (await r.json())["ok"] is False)
        r = await c.post("/api/login", json={"password": "secret123"})
        j = await r.json()
        check("login ok + csrf", j["ok"] and j.get("csrf"))
        r = await c.post("/api/public", json={})
        check("POST without csrf -> 403", r.status == 403)
        r = await c.post("/api/public", json={}, headers={"X-CSRF": j["csrf"]})
        check("POST with csrf ok", (await r.json())["ok"])
        r = await c.get("/api/state")
        j2 = await r.json()
        check("authed state has sources, token masked", len(j2["sources"]) == len(keys)
              and "token_masked" in j2 and "bot_token" not in j2)
        r = await c.get("/")
        check("security headers", r.headers.get("X-Frame-Options") == "DENY")

asyncio.run(web_test())

print("== 8) zip builder ==")
zpath = asyncio.run(asyncio.to_thread(bot._build_zip))
import zipfile
check("zip built", zipfile.is_zipfile(zpath))

if LIVE:
    print("== 9) LIVE: one full polling round ==")

    async def live():
        q = asyncio.Queue()
        eng = sources.Engine(q)
        t0 = time.time()
        await eng.one_round()
        dt = time.time() - t0
        got = []
        while not q.empty():
            got.append(db.get_media(q.get_nowait()[0]))
        return dt, got, eng.stats

    dt, got, eng_stats = asyncio.run(live())
    print(f"  round took {dt:.1f}s, {len(got)} new items")
    for g in got:
        print(f"    {g['kind']:5} {g['src']:22} {g['width']}x{g['height']} "
              f"{g['size']/1e6:.1f}MB age={int(time.time()-g['img_time'])//60}min")
    print("  engine stats:", eng_stats)
    check("live round < 300s", dt < 300)
    check("live round produced items", len(got) > 5)
    check("live: Iran/ME item present", any(g["cc"] in ("IR", "ME") for g in got))
    bad = [s for s in db.src_all() if s["fails"]]
    print("  failing sources:", [(b["key"], b["last_err"]) for b in bad])
    check("live: <=3 failing sources", len(bad) <= 3)

shutil.rmtree(TMP, ignore_errors=True)
print(f"\n===== RESULT: {PASS} passed, {FAIL} failed =====")
sys.exit(1 if FAIL else 0)
