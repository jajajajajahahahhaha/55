"""SpaceWatch v2 — central configuration.
Everything can be overridden with environment variables (SW_*)."""
import os


def _int(name, default):
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


# --- polling -----------------------------------------------------------------
POLL_INTERVAL = _int("SW_POLL_INTERVAL", 30)     # seconds between rounds
CONCURRENCY = _int("SW_CONCURRENCY", 6)          # parallel source fetches
HTTP_TIMEOUT = _int("SW_HTTP_TIMEOUT", 40)       # seconds per request
VIDEO_TIMEOUT = _int("SW_VIDEO_TIMEOUT", 240)    # seconds per video download
# a source that keeps failing is backed off exponentially up to this (sec)
MAX_BACKOFF = _int("SW_MAX_BACKOFF", 1800)

# --- telegram limits ---------------------------------------------------------
MAX_TG_PHOTO = 10 * 1024 * 1024    # sendPhoto limit -> above this use document
MAX_TG_DOC = 49 * 1024 * 1024      # above this -> direct download link
MAX_PHOTO_SIDE = 10000             # Telegram rejects photos with w+h > 10000
MAX_VIDEO_MB = _int("SW_MAX_VIDEO_MB", 48)   # bigger videos -> link
ENABLE_VIDEO = os.environ.get("SW_ENABLE_VIDEO", "1") == "1"

# --- network / storage -------------------------------------------------------
WEB_HOST = os.environ.get("SW_WEB_HOST", "0.0.0.0")
WEB_PORT = _int("SW_WEB_PORT", 8080)
FILE_PORT = _int("SW_FILE_PORT", 8090)
DATA_DIR = os.environ.get("SW_DATA_DIR", "data")
IMG_DIR = os.path.join(DATA_DIR, "images")
VID_DIR = os.path.join(DATA_DIR, "videos")
FILE_DIR = os.path.join(DATA_DIR, "files")
DB_PATH = os.path.join(DATA_DIR, "bot.db")
LOG_PATH = os.path.join(DATA_DIR, "bot.log")

# --- retention (keeps disk & RAM low) ---------------------------------------
KEEP_DAYS = _int("SW_KEEP_DAYS", 7)              # delete media older than this
MAX_DISK_MB = _int("SW_MAX_DISK_MB", 3000)       # hard cap for data/ folder
MEM_SOFT_LIMIT_MB = _int("SW_MEM_SOFT_MB", 700)  # watchdog: gc + drop caches
MEM_HARD_LIMIT_MB = _int("SW_MEM_HARD_MB", 900)  # watchdog: restart bot layer

# --- security ----------------------------------------------------------------
SESSION_HOURS = _int("SW_SESSION_HOURS", 24 * 14)
LOGIN_MAX_FAILS = 6           # per IP per 15 minutes
LOGIN_WINDOW = 900

# freshness: how old (sec) an item may be and still be considered "new"
# (protects against sources that re-serve very old imagery after restart)
MAX_ITEM_AGE = _int("SW_MAX_ITEM_AGE", 3 * 86400)

UA = "Mozilla/5.0 (X11; Linux x86_64) SpaceWatchBot/2.0 (+https://github.com/abol-png6666/166; official public imagery)"


def ensure_dirs():
    for d in (IMG_DIR, VID_DIR, FILE_DIR):
        os.makedirs(d, exist_ok=True)
