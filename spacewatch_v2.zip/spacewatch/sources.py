"""Source registry + polling engine (v2).

Design
  * Every source is a dict in SOURCES with a `kind` (image|video) and a
    `fetch` strategy: direct URL, EUMETSAT WMS, EPIC API, Himawari JSON,
    SWPC JSON list, ESA d2d JSON, RSS.
  * Sources are fetched **in parallel** (bounded by config.CONCURRENCY).
  * Conditional requests (ETag / If-Modified-Since) mean an unchanged
    image costs one tiny 304 round-trip instead of a multi-MB download.
  * Each source has its own cadence (`every`), so a 10-min product isn't
    hammered every 30 s while fast products still get checked every round.
  * Failing sources back off exponentially and are never allowed to stall
    the others.
  * Capture time is parsed from the *filename/metadata* where possible,
    otherwise from Last-Modified — never "now" (fixes the wrong delay).
  * Items older than config.MAX_ITEM_AGE are archived silently (not pushed),
    fixing "bot sends very old images on first start".
"""
import asyncio
import calendar
import hashlib
import io
import logging
import os
import re
import shutil
import time
from datetime import datetime
from email.utils import parsedate_to_datetime

import aiohttp
from PIL import Image, ImageFile

import config
import database as db
from repair import detect_partial, is_dark, is_truncated, make_preview, try_repair

log = logging.getLogger("sources")
ImageFile.LOAD_TRUNCATED_IMAGES = True
Image.MAX_IMAGE_PIXELS = None

WMS = ("https://view.eumetsat.int/geoserver/wms?service=WMS&version=1.3.0&request=GetMap"
       "&layers={layer}&styles=&format=image%2Fjpeg&crs=EPSG%3A4326"
       "&bbox={bbox}&width={w}&height={h}")
WMS_CAPS = "https://view.eumetsat.int/geoserver/wms?service=WMS&version=1.3.0&request=GetCapabilities"

# bbox is  south,west,north,east  (EPSG:4326 axis order in WMS 1.3.0)
BBOX_IRAN = "24,43,41,64"          # Iran + Gulf
BBOX_ME = "10,25,45,70"            # Middle East: Egypt..Pakistan, Yemen..Caucasus
BBOX_IODC_FD = "-77,-35.5,77,118.5"
BBOX_MTG_FD = "-77,-81,77,81"
BBOX_MSG0_FD = "-77,-77,77,77"

# ---------------------------------------------------------------------------
# SOURCE REGISTRY
#   key       unique id (also used by /latest <key>)
#   sat       display name
#   region    Persian label   region_en English label   cc ISO/region code
#   every     minimum seconds between checks
#   kind      image | video
#   type      direct | wms | epic | himawari | swpc | esa | rss | fy4
#   visual    run the visual partial-band detector (Earth full-disk only)
#   dark_skip skip renders that are almost black (night side of VIS layers)
#   group     for the /sources listing
# ---------------------------------------------------------------------------
SOURCES = [
    # ---------------- Middle East / Iran (Meteosat-9 IODC @45.5°E, MTG-I1) ----
    dict(key="iodc_iran_natural", sat="Meteosat-9 IODC / EUMETSAT — Natural Colour", type="wms",
         layer="msg_iodc:rgb_natural", bbox=BBOX_IRAN, w=1600, h=1296, every=600,
         region="ایران و خلیج فارس — رنگ طبیعی (روز)", region_en="Iran & Persian Gulf — natural colour (day)",
         cc="IR", dark_skip=True, group="me"),
    dict(key="iodc_iran_ir", sat="Meteosat-9 IODC / EUMETSAT — IR 10.8µm", type="wms",
         layer="msg_iodc:ir108", bbox=BBOX_IRAN, w=1600, h=1296, every=900,
         region="ایران و خلیج فارس — مادون‌قرمز (شبانه‌روزی، ابرها)", region_en="Iran & Persian Gulf — infrared (24h clouds)",
         cc="IR", group="me"),
    dict(key="iodc_iran_dust", sat="Meteosat-9 IODC / EUMETSAT — Dust RGB", type="wms",
         layer="msg_iodc:rgb_dust", bbox=BBOX_IRAN, w=1600, h=1296, every=1800,
         region="ایران — گرد و غبار (شبانه‌روزی)", region_en="Iran — dust RGB (24h)", cc="IR", group="me"),
    dict(key="mtg_iran_geocolour", sat="Meteosat-12 MTG-I1 / EUMETSAT — GeoColour", type="wms",
         layer="mtg_fd:rgb_geocolour", bbox=BBOX_IRAN, w=1600, h=1296, every=600,
         region="ایران — GeoColour (روز: رنگ واقعی، شب: نور شهرها)", region_en="Iran — GeoColour (day true-colour / night city lights)",
         cc="IR", group="me"),
    dict(key="mtg_me_truecolour", sat="Meteosat-12 MTG-I1 / EUMETSAT — True Colour", type="wms",
         layer="mtg_fd:rgb_truecolour", bbox=BBOX_ME, w=1600, h=1244, every=600,
         region="خاورمیانه — رنگ واقعی (روز)", region_en="Middle East — true colour (day)",
         cc="ME", dark_skip=True, group="me"),
    dict(key="iodc_me_natural", sat="Meteosat-9 IODC / EUMETSAT — Natural Colour", type="wms",
         layer="msg_iodc:rgb_natural", bbox=BBOX_ME, w=1600, h=1244, every=900,
         region="خاورمیانه — رنگ طبیعی (روز)", region_en="Middle East — natural colour (day)",
         cc="ME", dark_skip=True, group="me"),
    dict(key="iodc_me_airmass", sat="Meteosat-9 IODC / EUMETSAT — Airmass RGB", type="wms",
         layer="msg_iodc:rgb_airmass", bbox=BBOX_ME, w=1600, h=1244, every=1800,
         region="خاورمیانه — توده هوا (شبانه‌روزی)", region_en="Middle East — airmass RGB (24h)", cc="ME", group="me"),
    dict(key="iodc_fulldisk", sat="Meteosat-9 IODC / EUMETSAT — Full Disk IR", type="wms",
         layer="msg_iodc:ir108", bbox=BBOX_IODC_FD, w=1400, h=1400, every=1800,
         region="اقیانوس هند، خاورمیانه، آفریقای شرقی — دیسک کامل", region_en="Indian Ocean, Middle East, East Africa — full disk",
         cc="IR", group="me"),

    # ---------------- Europe / Africa (Meteosat 0°) --------------------------
    dict(key="mtg_fulldisk", sat="Meteosat-12 MTG-I1 / EUMETSAT — GeoColour", type="wms",
         layer="mtg_fd:rgb_geocolour", bbox=BBOX_MTG_FD, w=1400, h=1400, every=1800,
         region="اروپا، آفریقا، اطلس — دیسک کامل", region_en="Europe, Africa, Atlantic — full disk",
         cc="EU", group="earth"),
    dict(key="msg0_fulldisk", sat="Meteosat-10 (MSG) / EUMETSAT — Natural Colour", type="wms",
         layer="msg_fes:rgb_natural", bbox=BBOX_MSG0_FD, w=1400, h=1400, every=1800,
         region="اروپا و آفریقا — رنگ طبیعی", region_en="Europe & Africa — natural colour",
         cc="EU", dark_skip=True, group="earth"),

    # ---------------- Americas (GOES-19 East / GOES-18 West) -----------------
    dict(key="goes19_fd", sat="GOES-19 (East) / NOAA — GeoColor", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/FD/GEOCOLOR/1808x1808.jpg", every=600,
         region="نیمکره غربی — آمریکا و اقیانوس اطلس", region_en="Western hemisphere — Americas & Atlantic",
         cc="US", visual=True, group="earth"),
    dict(key="goes18_fd", sat="GOES-18 (West) / NOAA — GeoColor", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES18/ABI/FD/GEOCOLOR/1808x1808.jpg", every=600,
         region="اقیانوس آرام — غرب آمریکا", region_en="Pacific — western Americas",
         cc="US", visual=True, group="earth"),
    dict(key="goes19_conus", sat="GOES-19 / NOAA — CONUS GeoColor", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/CONUS/GEOCOLOR/1250x750.jpg", every=300,
         region="ایالات متحده — هر ۵ دقیقه", region_en="Continental US — every 5 min",
         cc="US", group="earth"),
    dict(key="goes19_meso1", sat="GOES-19 / NOAA — Mesoscale-1", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/MESO/M1/GEOCOLOR/latest.jpg", every=300,
         region="منطقه‌ی مزوسکیل (طوفان/رویداد) — هر ۱ دقیقه", region_en="Mesoscale sector (storm/event) — 1-min imagery",
         cc="US", group="earth"),
    dict(key="goes19_taw", sat="GOES-19 / NOAA — Tropical Atlantic", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/SECTOR/taw/GEOCOLOR/1800x1080.jpg", every=900,
         region="اطلس گرمسیری — کارائیب و طوفان‌ها", region_en="Tropical Atlantic — Caribbean & hurricanes",
         cc="US", group="earth"),
    dict(key="goes18_hi", sat="GOES-18 / NOAA — Hawaii", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES18/ABI/SECTOR/hi/GEOCOLOR/1200x1200.jpg", every=900,
         region="هاوایی — اقیانوس آرام مرکزی", region_en="Hawaii — central Pacific", cc="US", group="earth"),

    # ---------------- Asia / Pacific -----------------------------------------
    dict(key="himawari", sat="Himawari-9 / JMA-NICT — True Colour", type="himawari", every=600,
         region="شرق آسیا و اقیانوسیه — ژاپن", region_en="East Asia & Oceania — Japan", cc="JP",
         visual=True, group="earth"),
    dict(key="fy4b", sat="FY-4B / CMA (China) — GeoColor", type="direct",
         url="http://img.nsmc.org.cn/CLOUDIMAGE/FY4B/AGRI/GCLR/FY4B_DISK_GCLR.JPG", every=900,
         region="آسیا، هند، اقیانوس هند — دیسک کامل (چین)", region_en="Asia, India, Indian Ocean — full disk (China)",
         cc="CN", group="earth"),

    # ---------------- Whole Earth --------------------------------------------
    dict(key="epic", sat="DSCOVR EPIC / NASA", type="epic", every=1800,
         region="زمین از فاصله ۱.۵ میلیون کیلومتر", region_en="Earth from 1.5 million km",
         cc="", group="earth"),

    # ---------------- Sun ------------------------------------------------------
    dict(key="sdo_193", sat="SDO / NASA — AIA 193Å", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_2048_0193.jpg", every=300,
         region="خورشید — تاج (۱.۲ میلیون کلوین)", region_en="Sun — corona (1.2 MK)", cc="SUN", group="sun"),
    dict(key="sdo_304", sat="SDO / NASA — AIA 304Å", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_2048_0304.jpg", every=300,
         region="خورشید — کروموسفر و زبانه‌ها", region_en="Sun — chromosphere & prominences", cc="SUN", group="sun"),
    dict(key="sdo_171", sat="SDO / NASA — AIA 171Å", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_2048_0171.jpg", every=300,
         region="خورشید — حلقه‌های تاج", region_en="Sun — coronal loops", cc="SUN", group="sun"),
    dict(key="sdo_131", sat="SDO / NASA — AIA 131Å", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0131.jpg", every=600,
         region="خورشید — شراره‌ها (۱۰ میلیون کلوین)", region_en="Sun — flares (10 MK)", cc="SUN", group="sun"),
    dict(key="sdo_hmi", sat="SDO / NASA — HMI Intensitygram", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_2048_HMII.jpg", every=900,
         region="خورشید — فتوسفر و لکه‌های خورشیدی", region_en="Sun — photosphere & sunspots", cc="SUN", group="sun"),
    dict(key="sdo_hmib", sat="SDO / NASA — HMI Magnetogram", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_HMIB.jpg", every=900,
         region="خورشید — میدان مغناطیسی", region_en="Sun — magnetic field", cc="SUN", group="sun"),
    dict(key="sdo_composite", sat="SDO / NASA — 211/193/171 Composite", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/latest_2048_211193171.jpg", every=600,
         region="خورشید — ترکیب سه طول‌موج", region_en="Sun — 3-wavelength composite", cc="SUN", group="sun"),
    dict(key="suvi_195", sat="GOES-19 SUVI / NOAA — 195Å", type="swpc",
         url="https://services.swpc.noaa.gov/products/animations/suvi-primary-195.json", every=600,
         region="خورشید — تاج (SUVI)", region_en="Sun — corona (SUVI)", cc="SUN", group="sun"),
    dict(key="suvi_304", sat="GOES-19 SUVI / NOAA — 304Å", type="swpc",
         url="https://services.swpc.noaa.gov/products/animations/suvi-primary-304.json", every=600,
         region="خورشید — کروموسفر (SUVI)", region_en="Sun — chromosphere (SUVI)", cc="SUN", group="sun"),
    dict(key="lasco_c2", sat="SOHO LASCO C2 / NASA-ESA", type="swpc",
         url="https://services.swpc.noaa.gov/products/animations/lasco-c2.json", every=900,
         region="تاج خورشید — کروناگراف C2 (فوران‌های CME)", region_en="Solar corona — C2 coronagraph (CMEs)", cc="SUN", group="sun"),
    dict(key="lasco_c3", sat="SOHO LASCO C3 / NASA-ESA", type="swpc",
         url="https://services.swpc.noaa.gov/products/animations/lasco-c3.json", every=900,
         region="تاج خورشید — کروناگراف C3 (میدان وسیع)", region_en="Solar corona — C3 coronagraph (wide field)", cc="SUN", group="sun"),
    dict(key="ccor1", sat="GOES-19 CCOR-1 / NOAA", type="direct",
         url="https://services.swpc.noaa.gov/images/animations/ccor1/latest.jpg", every=900,
         region="تاج خورشید — کروناگراف CCOR-1", region_en="Solar corona — CCOR-1 coronagraph", cc="SUN", group="sun"),
    dict(key="stereo_a", sat="STEREO-A EUVI 195 / NASA", type="direct",
         url="https://stereo-ssc.nascom.nasa.gov/beacon/latest_256/ahead_euvi_195_latest.jpg", every=1800,
         region="خورشید از زاویه‌ای دیگر (STEREO-A)", region_en="Sun from another angle (STEREO-A)",
         cc="SUN", min_bytes=3000, group="sun"),

    # ---------------- Space weather --------------------------------------------
    dict(key="aurora_n", sat="NOAA SWPC — OVATION Aurora Forecast (North)", type="swpc",
         url="https://services.swpc.noaa.gov/products/animations/ovation_north_24h.json", every=1800,
         region="پیش‌بینی شفق قطبی — نیمکره شمالی", region_en="Aurora forecast — northern hemisphere",
         cc="", group="spaceweather"),
    dict(key="enlil", sat="NOAA SWPC — WSA-Enlil Solar Wind Model", type="direct",
         url="https://services.swpc.noaa.gov/images/animations/enlil/latest.jpg", every=3600,
         region="مدل باد خورشیدی تا زمین", region_en="Solar wind model Sun→Earth", cc="", group="spaceweather"),

    # ---------------- Deep space (telescopes) -----------------------------------
    dict(key="webb", sat="JWST / ESA-NASA-CSA", type="esa",
         url="https://esawebb.org/images/d2d/", every=1800, cc="DEEP", group="deep",
         region="فضای عمیق — تلسکوپ جیمز وب", region_en="Deep space — James Webb"),
    dict(key="hubble", sat="Hubble / ESA-NASA", type="esa",
         url="https://esahubble.org/images/d2d/", every=1800, cc="DEEP", group="deep",
         region="فضای عمیق — هابل", region_en="Deep space — Hubble"),
    dict(key="nasa_iotd", sat="NASA — Image of the Day", type="rss",
         url="https://www.nasa.gov/feeds/iotd-feed/", every=3600, cc="DEEP", group="deep",
         region="ناسا — تصویر روز", region_en="NASA — Image of the Day"),
    dict(key="apod", sat="NASA — Astronomy Picture of the Day", type="apod",
         url="https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY", every=3600, cc="DEEP", group="deep",
         region="تصویر نجومی روز (APOD)", region_en="Astronomy Picture of the Day"),

    # ================= VIDEO =====================================================
    dict(key="v_sdo_193", kind="video", sat="SDO / NASA — AIA 193Å (48h time-lapse)", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/mpeg/latest_512_0193.mp4", every=3600,
         region="خورشید — ۴۸ ساعت گذشته", region_en="Sun — last 48 hours", cc="SUN", group="video"),
    dict(key="v_sdo_304", kind="video", sat="SDO / NASA — AIA 304Å (48h time-lapse)", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/mpeg/latest_512_0304.mp4", every=3600,
         region="خورشید — زبانه‌ها، ۴۸ ساعت", region_en="Sun — prominences, 48 h", cc="SUN", group="video"),
    dict(key="v_sdo_composite", kind="video", sat="SDO / NASA — 3-wavelength (48h)", type="direct",
         url="https://sdo.gsfc.nasa.gov/assets/img/latest/mpeg/latest_512_211193171.mp4", every=3600,
         region="خورشید — ترکیب سه طول‌موج", region_en="Sun — 3-wavelength composite", cc="SUN", group="video"),
    dict(key="v_goes19_conus", kind="video", sat="GOES-19 / NOAA — CONUS loop", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/CONUS/GEOCOLOR/GOES19-CONUS-GEOCOLOR-625x375.mp4", every=1800,
         region="ایالات متحده — لوپ ۴ ساعته", region_en="Continental US — 4-hour loop", cc="US", group="video"),
    dict(key="v_goes19_mex", kind="video", sat="GOES-19 / NOAA — Mexico & Central America loop", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/SECTOR/mex/GEOCOLOR/GOES19-MEX-GEOCOLOR-1000x1000.mp4", every=3600,
         region="مکزیک و آمریکای مرکزی", region_en="Mexico & Central America", cc="MX", group="video"),
    dict(key="v_goes19_taw", kind="video", sat="GOES-19 / NOAA — Tropical Atlantic loop", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES19/ABI/SECTOR/taw/GEOCOLOR/GOES19-TAW-GEOCOLOR-900x540.mp4", every=3600,
         region="اطلس گرمسیری — طوفان‌ها", region_en="Tropical Atlantic — hurricanes", cc="US", group="video"),
    dict(key="v_goes18_hi", kind="video", sat="GOES-18 / NOAA — Hawaii loop", type="direct",
         url="https://cdn.star.nesdis.noaa.gov/GOES18/ABI/SECTOR/hi/GEOCOLOR/GOES18-HI-GEOCOLOR-600x600.mp4", every=3600,
         region="هاوایی", region_en="Hawaii", cc="US", group="video"),
    dict(key="v_soho_c2", kind="video", sat="SOHO LASCO C2 / NASA-ESA (movie)", type="direct",
         url="https://soho.nascom.nasa.gov/data/LATEST/current_c2.mpg", every=3600, transcode=True,
         region="تاج خورشید — فیلم C2", region_en="Solar corona — C2 movie", cc="SUN", group="video"),
    dict(key="v_soho_c3", kind="video", sat="SOHO LASCO C3 / NASA-ESA (movie)", type="direct",
         url="https://soho.nascom.nasa.gov/data/LATEST/current_c3.mpg", every=3600, transcode=True,
         region="تاج خورشید — فیلم C3", region_en="Solar corona — C3 movie", cc="SUN", group="video"),
    dict(key="v_webb", kind="video", sat="JWST / ESA — video release", type="esa_video",
         url="https://esawebb.org/videos/d2d/", every=3600, cc="DEEP", group="video",
         region="فضای عمیق — ویدیوی جیمز وب", region_en="Deep space — Webb video"),
    dict(key="v_hubble", kind="video", sat="Hubble / ESA — video release", type="esa_video",
         url="https://esahubble.org/videos/d2d/", every=3600, cc="DEEP", group="video",
         region="فضای عمیق — ویدیوی هابل", region_en="Deep space — Hubble video"),
]
for _s in SOURCES:
    _s.setdefault("kind", "image")
    _s.setdefault("visual", False)
    _s.setdefault("dark_skip", False)
    _s.setdefault("min_bytes", 5000)
    _s.setdefault("transcode", False)
    _s.setdefault("region_en", _s.get("region", ""))
SOURCE_MAP = {s["key"]: s for s in SOURCES}
GROUPS = {"me": ("🇮🇷 خاورمیانه و ایران", "Middle East & Iran"),
          "earth": ("🌍 زمین", "Earth"), "sun": ("☀️ خورشید", "Sun"),
          "spaceweather": ("🌌 آب‌وهوای فضایی", "Space weather"),
          "deep": ("🔭 فضای عمیق", "Deep space"), "video": ("🎬 ویدیو", "Video")}

EPIC_API = "https://epic.gsfc.nasa.gov/api/natural"
EPIC_ARC = "https://epic.gsfc.nasa.gov/archive/natural/{y}/{m}/{d}/jpg/{img}.jpg"
HIMA_JSON = "https://himawari8-dl.nict.go.jp/himawari8/img/D531106/latest.json"
HIMA_IMG = "https://himawari8-dl.nict.go.jp/himawari8/img/D531106/1d/550/{y}/{m}/{d}/{hms}_0_0.png"

COUNTRY = {"IR": "ایران", "US": "آمریکا", "CN": "چین", "IN": "هند", "RU": "روسیه",
           "BR": "برزیل", "AU": "استرالیا", "SA": "عربستان", "EG": "مصر", "TR": "ترکیه",
           "PK": "پاکستان", "ZA": "آفریقای جنوبی", "FR": "فرانسه", "DE": "آلمان",
           "GB": "بریتانیا", "JP": "ژاپن", "IQ": "عراق", "AF": "افغانستان", "OM": "عمان",
           "AE": "امارات", "QA": "قطر", "MX": "مکزیک", "ID": "اندونزی", "AR": "آرژانتین",
           "CA": "کانادا", "KZ": "قزاقستان", "MN": "مغولستان", "DZ": "الجزایر", "LY": "لیبی",
           "SD": "سودان", "ET": "اتیوپی", "KE": "کنیا", "TZ": "تانزانیا", "MG": "ماداگاسکار",
           "PE": "پرو", "CL": "شیلی", "CO": "کلمبیا", "VE": "ونزوئلا", "ES": "اسپانیا",
           "IT": "ایتالیا", "UA": "اوکراین", "TH": "تایلند", "VN": "ویتنام", "PH": "فیلیپین",
           "PG": "پاپوآ گینه نو", "NZ": "نیوزیلند", "MA": "مراکش", "NG": "نیجریه", "AO": "آنگولا"}

_geo_lock = asyncio.Lock()


def _geocode_sync(lat, lon):
    try:
        import reverse_geocoder as rg
        res = rg.search([(lat, lon)], mode=1, verbose=False)   # mode=1: single process, low RAM
        return res[0]["cc"] if res else ""
    except Exception as e:
        log.debug("geocode failed: %s", e)
        return ""


async def cc_to_region(lat, lon):
    async with _geo_lock:
        cc = await asyncio.to_thread(_geocode_sync, lat, lon)
    name = COUNTRY.get(cc, cc or "اقیانوس")
    fa = f"زمین — مرکز تصویر روی {name} ({lat:.1f}°, {lon:.1f}°)"
    en = f"Earth — image centre over {cc or 'ocean'} ({lat:.1f}°, {lon:.1f}°)"
    return fa, en, cc


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------
class NotModified(Exception):
    pass


async def http_get(session, url, *, key=None, conditional=True, timeout=None,
                   json_mode=False, max_bytes=None, to_file=None):
    """GET with optional conditional headers taken from source_state[key].
    Raises NotModified on 304. Returns (body_or_path, headers)."""
    headers = {"User-Agent": config.UA, "Accept": "*/*"}
    if key and conditional:
        st = db.src_state(key)
        if st.get("etag"):
            headers["If-None-Match"] = st["etag"]
        if st.get("last_mod"):
            headers["If-Modified-Since"] = st["last_mod"]
    tmo = aiohttp.ClientTimeout(total=timeout or config.HTTP_TIMEOUT, sock_read=60)
    async with session.get(url, headers=headers, timeout=tmo, allow_redirects=True) as r:
        if r.status == 304:
            raise NotModified()
        if r.status != 200:
            raise aiohttp.ClientResponseError(r.request_info, r.history, status=r.status,
                                              message=f"HTTP {r.status}")
        cl = r.headers.get("Content-Length")
        if max_bytes and cl and int(cl) > max_bytes:
            raise ValueError(f"too large ({int(cl) // 1048576} MB)")
        if json_mode:
            return await r.json(content_type=None), r.headers
        if to_file:
            n = 0
            with open(to_file, "wb") as f:
                async for chunk in r.content.iter_chunked(256 * 1024):
                    f.write(chunk)
                    n += len(chunk)
                    if max_bytes and n > max_bytes:
                        raise ValueError("too large (stream)")
            return to_file, r.headers
        body = await r.read()
        if max_bytes and len(body) > max_bytes:
            raise ValueError("too large")
        return body, r.headers


def http_time(headers):
    lm = (headers or {}).get("Last-Modified")
    if lm:
        try:
            return parsedate_to_datetime(lm).timestamp()
        except Exception:
            pass
    return None


def parse_wms_time(headers):
    """Fallback only — EUMETView's Last-Modified is a cache time, not the slot."""
    return http_time(headers)


_caps_cache = {"ts": 0.0, "slots": {}}
_caps_lock = asyncio.Lock()
async def wms_latest_slots(session, max_age=240):
    """{layer: (iso_slot, epoch)} of the newest available time per layer.
    Cached for `max_age` seconds; one 280 KB request serves all WMS sources."""
    async with _caps_lock:
        if time.time() - _caps_cache["ts"] < max_age and _caps_cache["slots"]:
            return _caps_cache["slots"]
        try:
            xml, _ = await http_get(session, WMS_CAPS, conditional=False, timeout=60)
            txt = xml.decode("utf-8", "ignore")
            slots = {}
            # iterate <Layer> blocks cheaply
            for blk in txt.split("<Layer")[1:]:
                m = re.search(r"<Name>([a-z0-9_]+:[a-z0-9_]+)</Name>", blk)
                d = re.search(r'<Dimension name="time"[^>]*>([^<]*)</Dimension>', blk)
                if not m or not d:
                    continue
                # value like  start/end/PTxxM  or a comma list; take the last end
                val = d.group(1).strip().split(",")[-1]
                end = val.split("/")[1] if "/" in val else val
                try:
                    ep = calendar.timegm(time.strptime(end[:19], "%Y-%m-%dT%H:%M:%S"))
                except Exception:
                    continue
                slots[m.group(1)] = (end[:19] + "Z", ep)
            if slots:
                _caps_cache.update(ts=time.time(), slots=slots)
        except Exception as e:
            log.debug("GetCapabilities failed: %s", e)
        return _caps_cache["slots"]


_TS_PATTERNS = [
    # 20262511810_GOES19-...   (YYYYDDDHHMM julian)
    (re.compile(r"(\d{4})(\d{3})(\d{2})(\d{2})_GOES"), "julian"),
    # s20260908T184000Z  (SUVI)
    (re.compile(r"s(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})"), "ymdhm"),
    # 20260908_1424_c2   (LASCO)
    (re.compile(r"(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})_c"), "ymdhm"),
    # aurora_N_2026-09-08_1845
    (re.compile(r"(\d{4})-(\d{2})-(\d{2})_(\d{2})(\d{2})"), "ymdhm"),
]


def time_from_name(name):
    for rx, kind in _TS_PATTERNS:
        m = rx.search(name)
        if not m:
            continue
        try:
            if kind == "julian":
                y, doy, hh, mm = map(int, m.groups())
                return calendar.timegm(time.strptime(f"{y} {doy} {hh} {mm}", "%Y %j %H %M"))
            y, mo, d, hh, mm = map(int, m.groups())
            return calendar.timegm((y, mo, d, hh, mm, 0, 0, 0, 0))
        except Exception:
            continue
    return None


def sha1(data):
    return hashlib.sha1(data).hexdigest()


# ---------------------------------------------------------------------------
# Media ingestion
# ---------------------------------------------------------------------------
class Engine:
    def __init__(self, queue):
        self.queue = queue
        self.sem = asyncio.Semaphore(config.CONCURRENCY)
        self.video_sem = asyncio.Semaphore(1)     # one video download at a time (RAM/BW)
        self.session: aiohttp.ClientSession | None = None
        self.last_round = 0.0
        self.round_ms = 0
        self.rounds = 0
        self._last_check = {}      # key -> ts
        self.stats = {"new": 0, "skipped_old": 0, "skipped_dark": 0, "not_modified": 0, "errors": 0}
        self.started = time.time()

    # -------------------------------------------------- ingestion helpers ----
    async def ingest_image(self, s, data, headers, *, url, img_time=None, lat=None, lon=None,
                           region=None, region_en=None, cc=None, title=None):
        if not data or len(data) < s["min_bytes"]:
            return None
        h = sha1(data)
        if db.media_exists(h):
            return None
        st = db.src_state(s["key"])
        if st.get("last_hash") == h:
            return None
        truncated = await asyncio.to_thread(is_truncated, data)
        try:
            im = Image.open(io.BytesIO(data))
            w, hh = im.size
            fmt = (im.format or "JPEG").lower()
        except Exception:
            return None
        if img_time is None:
            img_time = http_time(headers)
        if img_time is None:
            img_time = time.time()
        ext = ".png" if fmt == "png" else ".jpg"
        path = os.path.join(config.IMG_DIR, f"{int(time.time())}_{s['key']}_{h[:8]}{ext}")
        with open(path, "wb") as f:
            f.write(data)
        del data
        if s["dark_skip"] and await asyncio.to_thread(is_dark, path):
            os.remove(path)
            self.stats["skipped_dark"] += 1
            db.src_update(s["key"], last_hash=h)
            return None
        partial = truncated or (s["visual"] and await asyncio.to_thread(detect_partial, path, True))
        repaired = await asyncio.to_thread(try_repair, path) if partial else None
        thumb = None
        if w + hh > config.MAX_PHOTO_SIDE or os.path.getsize(path) > config.MAX_TG_PHOTO:
            thumb = path.rsplit(".", 1)[0] + "_preview.jpg"
            try:
                await asyncio.to_thread(make_preview, path, thumb)
            except Exception as e:
                log.debug("preview failed: %s", e)
                thumb = None
        too_old = (time.time() - img_time) > config.MAX_ITEM_AGE
        mid = db.insert_media(dict(
            src=s["key"], url=url, hash=h, path=path, kind="image",
            region=region if region is not None else s["region"],
            region_en=region_en if region_en is not None else s["region_en"],
            cc=cc if cc is not None else s["cc"], lat=lat, lon=lon,
            sat=s["sat"] + (f" — {title}" if title else ""),
            img_time=img_time, fetched_at=time.time(),
            status="partial" if partial else "complete",
            width=w, height=hh, size=os.path.getsize(path),
            repaired_path=repaired, thumb_path=thumb, sent=1 if too_old else 0))
        db.src_update(s["key"], last_hash=h)
        if too_old:
            self.stats["skipped_old"] += 1
            log.info("archived old item %s (%.1f h old) id=%s", s["key"],
                     (time.time() - img_time) / 3600, mid)
            return mid
        self.stats["new"] += 1
        log.info("NEW %s partial=%s %dx%d -> id=%s", s["key"], partial, w, hh, mid)
        await self.queue.put((mid, "new"))
        return mid

    async def ingest_video(self, s, url, *, img_time=None, title=None, headers=None):
        if not config.ENABLE_VIDEO:
            return None
        async with self.video_sem:
            tmp = os.path.join(config.VID_DIR, f"dl_{s['key']}_{int(time.time())}.part")
            try:
                _, hdrs = await http_get(self.session, url, key=s["key"], timeout=config.VIDEO_TIMEOUT,
                                         to_file=tmp, max_bytes=(config.MAX_VIDEO_MB + 30) * 1048576)
            except NotModified:
                self.stats["not_modified"] += 1
                return None
            headers = headers or hdrs
            h = await asyncio.to_thread(_file_sha1, tmp)
            if db.media_exists(h) or db.src_state(s["key"]).get("last_hash") == h:
                os.remove(tmp)
                return None
            final = os.path.join(config.VID_DIR, f"{int(time.time())}_{s['key']}_{h[:8]}.mp4")
            ok = await asyncio.to_thread(_finalize_video, tmp, final, s["transcode"] or not url.lower().endswith(".mp4"))
            if not ok:
                db.src_update(s["key"], last_hash=h)
                return None
            meta = await asyncio.to_thread(_probe_video, final)
            thumb = final.rsplit(".", 1)[0] + "_thumb.jpg"
            await asyncio.to_thread(_video_thumb, final, thumb)
            if img_time is None:
                img_time = http_time(headers) or time.time()
            too_old = (time.time() - img_time) > config.MAX_ITEM_AGE
            mid = db.insert_media(dict(
                src=s["key"], url=url, hash=h, path=final, kind="video",
                region=s["region"], region_en=s["region_en"], cc=s["cc"],
                sat=s["sat"] + (f" — {title}" if title else ""),
                img_time=img_time, fetched_at=time.time(), status="complete",
                width=meta.get("w", 0), height=meta.get("h", 0), duration=meta.get("dur", 0),
                size=os.path.getsize(final), thumb_path=thumb if os.path.exists(thumb) else None,
                sent=1 if too_old else 0))
            db.src_update(s["key"], last_hash=h)
            if too_old:
                self.stats["skipped_old"] += 1
                return mid
            self.stats["new"] += 1
            log.info("NEW VIDEO %s %.0fs %dMB -> id=%s", s["key"], meta.get("dur", 0),
                     os.path.getsize(final) // 1048576, mid)
            await self.queue.put((mid, "new"))
            return mid

    # -------------------------------------------------- per-type fetchers ----
    async def f_direct(self, s):
        if s["kind"] == "video":
            return await self.ingest_video(s, s["url"])
        data, hdr = await http_get(self.session, s["url"], key=s["key"],
                                   max_bytes=config.MAX_TG_DOC)
        db.src_update(s["key"], etag=hdr.get("ETag"), last_mod=hdr.get("Last-Modified"))
        t = time_from_name(s["url"]) or http_time(hdr)
        return await self.ingest_image(s, data, hdr, url=s["url"], img_time=t)

    async def f_wms(self, s):
        url = WMS.format(layer=s["layer"].replace(":", "%3A"), bbox=s["bbox"], w=s["w"], h=s["h"])
        slots = await wms_latest_slots(self.session)
        slot = slots.get(s["layer"])
        t = None
        if slot:
            iso, t = slot
            if db.src_state(s["key"]).get("last_mod") == iso:
                self.stats["not_modified"] += 1          # same slot -> nothing new
                return None
            url += f"&time={iso}"
        data, hdr = await http_get(self.session, url, key=s["key"], conditional=False, timeout=90)
        ct = hdr.get("Content-Type", "")
        if "image" not in ct:
            raise ValueError(f"WMS returned {ct[:40]}")
        r = await self.ingest_image(s, data, hdr, url=url, img_time=t or parse_wms_time(hdr))
        if slot:
            db.src_update(s["key"], last_mod=slot[0])
        return r

    async def f_epic(self, s):
        data, _ = await http_get(self.session, EPIC_API, key=s["key"], json_mode=True, conditional=False)
        if not data:
            return
        # newest 2 (the API returns the most recent *day* — typically 1-2 days old)
        for item in sorted(data, key=lambda i: i["date"], reverse=True)[:2]:
            d, _t = item["date"].split(" ")
            y, m, dd = d.split("-")
            url = EPIC_ARC.format(y=y, m=m, d=dd, img=item["image"])
            img_time = calendar.timegm(time.strptime(item["date"], "%Y-%m-%d %H:%M:%S"))
            cen = item.get("centroid_coordinates") or {}
            lat, lon = cen.get("lat"), cen.get("lon")
            region, region_en, cc = s["region"], s["region_en"], ""
            if lat is not None and lon is not None:
                region, region_en, cc = await cc_to_region(lat, lon)
            body, hdr = await http_get(self.session, url, conditional=False)
            await self.ingest_image(s, body, hdr, url=url, img_time=img_time, lat=lat, lon=lon,
                                    region=region, region_en=region_en, cc=cc)

    async def f_himawari(self, s):
        meta, _ = await http_get(self.session, HIMA_JSON, key=s["key"], json_mode=True, conditional=False)
        if not meta or "date" not in meta:
            return
        d, t = meta["date"].split(" ")
        y, m, dd = d.split("-")
        hms = t.replace(":", "")
        url = HIMA_IMG.format(y=y, m=m, d=dd, hms=hms)
        if db.src_state(s["key"]).get("last_mod") == meta["date"]:
            self.stats["not_modified"] += 1
            return
        img_time = calendar.timegm(time.strptime(meta["date"], "%Y-%m-%d %H:%M:%S"))
        body, hdr = await http_get(self.session, url, conditional=False)
        r = await self.ingest_image(s, body, hdr, url=url, img_time=img_time)
        db.src_update(s["key"], last_mod=meta["date"])
        return r

    async def f_swpc(self, s):
        lst, _ = await http_get(self.session, s["url"], key=s["key"], json_mode=True, conditional=False)
        if not lst:
            return
        last = lst[-1]
        rel = last.get("url")
        if not rel:
            return
        url = "https://services.swpc.noaa.gov" + rel if rel.startswith("/") else rel
        if db.src_state(s["key"]).get("last_mod") == url:
            self.stats["not_modified"] += 1
            return
        t = None
        if last.get("time_tag"):
            try:
                t = datetime.fromisoformat(last["time_tag"].replace("Z", "+00:00")).timestamp()
            except Exception:
                pass
        t = t or time_from_name(url)
        body, hdr = await http_get(self.session, url, conditional=False)
        r = await self.ingest_image(s, body, hdr, url=url, img_time=t or http_time(hdr))
        db.src_update(s["key"], last_mod=url)
        return r

    async def f_esa(self, s):
        data, _ = await http_get(self.session, s["url"], key=s["key"], json_mode=True, conditional=False,
                                 timeout=60)
        cols = (data or {}).get("Collections") or []
        for c in cols[:2]:
            pub = c.get("PublicationDate")
            try:
                t = datetime.fromisoformat(pub.replace("Z", "+00:00")).timestamp()
            except Exception:
                t = None
            # pick the "Large" JPEG (<= ~8 MB), fallback Small
            best = None
            for a in c.get("Assets", []):
                for r in a.get("Resources", []):
                    if r.get("MediaType") != "Image":
                        continue
                    u = r.get("URL", "")
                    if not u.lower().endswith((".jpg", ".jpeg", ".png")):
                        continue
                    if r.get("ResourceType") == "Large" and (r.get("FileSize") or 0) < config.MAX_TG_DOC:
                        best = u
                    elif r.get("ResourceType") == "Small" and best is None:
                        best = u
            if not best:
                continue
            if db.src_state(s["key"]).get("last_mod") == c.get("ID") and cols.index(c) == 0:
                self.stats["not_modified"] += 1
                return
            body, hdr = await http_get(self.session, best, conditional=False, max_bytes=config.MAX_TG_DOC)
            await self.ingest_image(s, body, hdr, url=c.get("ReferenceURL") or best, img_time=t,
                                    title=(c.get("Title") or "")[:80])
        if cols:
            db.src_update(s["key"], last_mod=cols[0].get("ID"))

    async def f_esa_video(self, s):
        data, _ = await http_get(self.session, s["url"], key=s["key"], json_mode=True, conditional=False,
                                 timeout=60)
        cols = (data or {}).get("Collections") or []
        if not cols:
            return
        c = cols[0]
        if db.src_state(s["key"]).get("last_mod") == c.get("ID"):
            self.stats["not_modified"] += 1
            return
        vid_id = c.get("ID")
        base = s["url"].split("/videos/")[0]
        cdn = base.replace("https://", "https://cdn.")
        pub = c.get("PublicationDate")
        try:
            t = datetime.fromisoformat(pub.replace("Z", "+00:00")).timestamp()
        except Exception:
            t = None
        # try progressively smaller renditions until one fits
        for rend in ("hd_1080p25_screen", "m_hd_1080p_screen", "medium_podcast", "small_flash"):
            url = f"{cdn}/archives/videos/{rend}/{vid_id}.mp4"
            try:
                async with self.session.head(url, headers={"User-Agent": config.UA},
                                             timeout=aiohttp.ClientTimeout(total=20)) as r:
                    if r.status != 200:
                        continue
                    size = int(r.headers.get("Content-Length") or 0)
                if size > (config.MAX_VIDEO_MB + 30) * 1048576:
                    continue
                await self.ingest_video(s, url, img_time=t, title=(c.get("Title") or "")[:80])
                break
            except Exception as e:
                log.debug("esa video %s: %s", rend, e)
        db.src_update(s["key"], last_mod=vid_id)

    async def f_rss(self, s):
        import feedparser
        raw, hdr = await http_get(self.session, s["url"], key=s["key"])
        db.src_update(s["key"], etag=hdr.get("ETag"), last_mod=hdr.get("Last-Modified"))
        parsed = await asyncio.to_thread(feedparser.parse, raw)
        for e in parsed.entries[:2]:
            img = _entry_image(e)
            if not img or not img.startswith("http"):
                continue
            t = calendar.timegm(e.published_parsed) if e.get("published_parsed") else None
            title = re.sub(r"\s+", " ", e.get("title", ""))[:80]
            body, h2 = await http_get(self.session, img, conditional=False, max_bytes=config.MAX_TG_DOC)
            await self.ingest_image(s, body, h2, url=e.get("link") or img, img_time=t, title=title)

    async def f_apod(self, s):
        j, _ = await http_get(self.session, s["url"], key=s["key"], json_mode=True, conditional=False)
        if not j or j.get("media_type") != "image":
            return
        url = j.get("hdurl") or j.get("url")
        if not url:
            return
        if db.src_state(s["key"]).get("last_mod") == j.get("date"):
            self.stats["not_modified"] += 1
            return
        try:
            t = calendar.timegm(time.strptime(j["date"], "%Y-%m-%d")) + 5 * 3600
        except Exception:
            t = None
        body, hdr = await http_get(self.session, url, conditional=False, max_bytes=config.MAX_TG_DOC)
        r = await self.ingest_image(s, body, hdr, url="https://apod.nasa.gov/apod/astropix.html",
                                    img_time=t, title=(j.get("title") or "")[:80])
        db.src_update(s["key"], last_mod=j.get("date"))
        return r

    async def f_fy4(self, s):
        return await self.f_direct(s)

    FETCHERS = {"direct": "f_direct", "wms": "f_wms", "epic": "f_epic", "himawari": "f_himawari",
                "swpc": "f_swpc", "esa": "f_esa", "esa_video": "f_esa_video", "rss": "f_rss",
                "apod": "f_apod", "fy4": "f_fy4"}

    # -------------------------------------------------------- scheduling ----
    def due(self, s, now):
        st = db.src_state(s["key"])
        if not st.get("enabled", 1):
            return False
        if st.get("next_try", 0) > now:
            return False
        if s["kind"] == "video" and not config.ENABLE_VIDEO:
            return False
        if s["kind"] == "video" and not db.flag("videos_enabled", True):
            return False
        last = self._last_check.get(s["key"], 0)
        return now - last >= s["every"] * 0.9   # allow a little jitter

    async def run_source(self, s):
        async with self.sem:
            t0 = time.time()
            self._last_check[s["key"]] = t0
            try:
                fn = getattr(self, self.FETCHERS[s["type"]])
                r = await asyncio.wait_for(fn(s), timeout=config.VIDEO_TIMEOUT + 60
                                           if s["kind"] == "video" else config.HTTP_TIMEOUT * 3)
                db.src_ok(s["key"], ms=(time.time() - t0) * 1000, new_item=bool(r))
            except NotModified:
                self.stats["not_modified"] += 1
                db.src_ok(s["key"], ms=(time.time() - t0) * 1000)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.stats["errors"] += 1
                delay = db.src_fail(s["key"], e)
                log.warning("%s failed (%s) -> retry in %ds", s["key"], str(e)[:120], delay)

    async def recheck_partials(self):
        for row in db.partials_due():
            try:
                data, hdr = await http_get(self.session, row["url"], conditional=False,
                                           max_bytes=config.MAX_TG_DOC)
                h = sha1(data)
                if h == row["hash"] or db.media_exists(h):
                    db.update_media(row["id"], rechecks=row["rechecks"] + 1)
                    continue
                if await asyncio.to_thread(is_truncated, data):
                    db.update_media(row["id"], rechecks=row["rechecks"] + 1)
                    continue
                im = Image.open(io.BytesIO(data))
                w, hh = im.size
                ext = os.path.splitext(row["path"])[1] or ".jpg"
                path = os.path.join(config.IMG_DIR, f"{int(time.time())}_{row['src']}_full_{h[:8]}{ext}")
                with open(path, "wb") as f:
                    f.write(data)
                s = SOURCE_MAP.get(row["src"], {})
                if s.get("visual") and await asyncio.to_thread(detect_partial, path, True):
                    os.remove(path)
                    db.update_media(row["id"], rechecks=row["rechecks"] + 1)
                    continue
                db.update_media(row["id"], hash=h, path=path, status="complete", width=w, height=hh,
                                size=len(data), img_time=http_time(hdr) or row["img_time"])
                log.info("partial %s completed -> resend", row["id"])
                await self.queue.put((row["id"], "completed"))
            except Exception as e:
                db.update_media(row["id"], rechecks=row["rechecks"] + 1)
                log.debug("recheck failed: %s", e)

    async def round(self):
        now = time.time()
        due = [s for s in SOURCES if self.due(s, now)]
        # images first, videos last (they're slow and take the video_sem)
        due.sort(key=lambda s: (s["kind"] == "video", s["every"]))
        if due:
            await asyncio.gather(*(self.run_source(s) for s in due), return_exceptions=True)
        await self.recheck_partials()
        self.rounds += 1
        self.last_round = time.time()
        self.round_ms = int((self.last_round - now) * 1000)

    async def loop(self):
        await asyncio.sleep(2)
        conn = aiohttp.TCPConnector(limit=config.CONCURRENCY + 2, ttl_dns_cache=600,
                                    enable_cleanup_closed=True)
        async with aiohttp.ClientSession(connector=conn, raise_for_status=False) as session:
            self.session = session
            while True:
                t0 = time.time()
                try:
                    await self.round()
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    log.exception("round failed: %s", e)
                dt = time.time() - t0
                await asyncio.sleep(max(3, config.POLL_INTERVAL - dt))

    def health(self):
        return dict(rounds=self.rounds, last_round=self.last_round, round_ms=self.round_ms,
                    started=self.started, **self.stats)

    # ---- task management (used by main.watchdog / webui) --------------------
    _task = None

    def start(self):
        if self._task and not self._task.done():
            return self._task
        self._task = asyncio.create_task(self.loop(), name="poll_loop")
        return self._task

    def alive(self):
        return self._task is not None and not self._task.done()

    async def stop(self):
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
            self._task = None

    @property
    def last_round_ms(self):
        return self.round_ms

    @property
    def last_round_at(self):
        return self.last_round

    async def one_round(self):
        """Run a single round with a temporary session (tests / CLI)."""
        conn = aiohttp.TCPConnector(limit=config.CONCURRENCY + 2, ttl_dns_cache=600)
        async with aiohttp.ClientSession(connector=conn, raise_for_status=False) as session:
            self.session = session
            await self.round()


# ---------------------------------------------------------------------------
def _entry_image(e):
    for l in e.get("links", []):
        if str(l.get("type", "")).startswith("image"):
            return l.get("href")
    for m in e.get("media_content", []) or []:
        if m.get("url") and str(m.get("type", "image")).startswith("image"):
            return m["url"]
    for enc in e.get("enclosures", []) or []:
        if str(enc.get("type", "")).startswith("image"):
            return enc.get("href") or enc.get("url")
    html = ""
    if e.get("content"):
        html = e.content[0].get("value", "")
    elif e.get("summary"):
        html = e.summary
    m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', html)
    return m.group(1) if m else None


def _file_sha1(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _ffmpeg():
    return shutil.which("ffmpeg")


def _finalize_video(tmp, final, transcode):
    """Move/transcode downloaded video into an mp4 that Telegram plays inline.
    Uses ffmpeg with -threads 1 and fast preset to stay light on CPU/RAM."""
    import subprocess
    ff = _ffmpeg()
    if not transcode or not ff:
        if transcode and not ff:
            log.warning("ffmpeg missing -> sending original container")
        os.replace(tmp, final)
        return True
    try:
        subprocess.run([ff, "-y", "-v", "error", "-threads", "1", "-i", tmp,
                        "-c:v", "libx264", "-preset", "veryfast", "-crf", "24",
                        "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-an", final],
                       check=True, timeout=600)
        os.remove(tmp)
        return True
    except Exception as e:
        log.warning("transcode failed: %s", e)
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


def _probe_video(path):
    import json
    import subprocess
    fp = shutil.which("ffprobe")
    if not fp:
        return {}
    try:
        out = subprocess.run([fp, "-v", "error", "-select_streams", "v:0", "-show_entries",
                              "stream=width,height:format=duration", "-of", "json", path],
                             capture_output=True, text=True, timeout=60).stdout
        j = json.loads(out)
        st = (j.get("streams") or [{}])[0]
        return dict(w=int(st.get("width", 0)), h=int(st.get("height", 0)),
                    dur=float(j.get("format", {}).get("duration", 0)))
    except Exception:
        return {}


def _video_thumb(path, out):
    import subprocess
    ff = _ffmpeg()
    if not ff:
        return
    try:
        subprocess.run([ff, "-y", "-v", "error", "-ss", "1", "-i", path, "-frames:v", "1",
                        "-vf", "scale=640:-2", out], check=True, timeout=60)
    except Exception as e:
        log.debug("thumb failed: %s", e)


ALL_KEYS = [s["key"] for s in SOURCES]


def region_text(region, lang):
    """Accepts (fa, en) tuple/list or plain string."""
    if isinstance(region, (tuple, list)):
        return region[0] if lang == "fa" else region[1]
    return region or ""


def source_catalog():
    """Human-readable list for /sources & the panel."""
    return [dict(key=s["key"], sat=s["sat"], kind=s["kind"], group=s.get("group", ""),
                 region=(s["region"], s["region_en"]), every=s["every"], type=s["type"])
            for s in SOURCES]


# retained for compatibility with tests / older imports
async def poll_loop(queue):
    await Engine(queue).loop()
