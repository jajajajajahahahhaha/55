#!/usr/bin/env bash
# 🛰️ SpaceWatch Bot v2 — نصب روی VPS (Ubuntu/Debian)
#   ./setup.sh            نصب + ساخت venv + سرویس systemd
#   ./setup.sh --no-service   فقط نصب، بدون systemd
set -e
cd "$(dirname "$0")"
HERE="$(pwd)"

echo "🛰️  نصب SpaceWatch v2 ..."

# 1) پیش‌نیازهای سیستمی (ffmpeg برای ویدیو، libgl برای OpenCV)
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -y -q
  sudo apt-get install -y -q python3 python3-venv python3-pip curl ffmpeg libgl1 libglib2.0-0
fi

# 2) محیط مجازی + کتابخانه‌ها
python3 -m venv venv
# shellcheck disable=SC1091
source venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt

# 3) cloudflared (لینک دانلود مستقیم فایل‌های بزرگ) — اختیاری
if ! command -v cloudflared >/dev/null 2>&1; then
  ARCH=$(uname -m); case "$ARCH" in x86_64) CF=amd64;; aarch64) CF=arm64;; armv7l) CF=arm;; *) CF=amd64;; esac
  echo "⬇️  دانلود cloudflared ($CF)..."
  curl -fsSL -o cloudflared "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$CF" \
    && chmod +x cloudflared && (sudo mv cloudflared /usr/local/bin/cloudflared 2>/dev/null || true) \
    || echo "⚠️  cloudflared نصب نشد (اختیاری است)"
fi

mkdir -p data/images data/videos data/files

# 4) systemd service (اجرای دائمی + ری‌استارت خودکار + محدودیت رم)
if [ "$1" != "--no-service" ] && command -v systemctl >/dev/null 2>&1; then
  sudo tee /etc/systemd/system/spacewatch.service >/dev/null <<EOF
[Unit]
Description=SpaceWatch Telegram Bot v2
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$HERE
ExecStart=$HERE/venv/bin/python $HERE/main.py
Restart=always
RestartSec=5
# self-heal at OS level: hard cap so a leak can never take the VPS down
MemoryMax=950M
MemoryHigh=800M
Nice=5
Environment=PYTHONUNBUFFERED=1
Environment=OMP_NUM_THREADS=1
Environment=OPENCV_FOR_THREADS_NUM=1
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
EOF
  sudo systemctl daemon-reload
  sudo systemctl enable spacewatch >/dev/null
  sudo systemctl restart spacewatch
  echo "✅ سرویس systemd فعال شد:  sudo systemctl status spacewatch"
  echo "   لاگ زنده:                 journalctl -u spacewatch -f"
else
  echo "ℹ️  اجرای دستی:  source venv/bin/activate && python main.py"
fi

IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo ""
echo "────────────────────────────────────────────"
echo "🌐 پنل وب:  http://${IP:-SERVER-IP}:8080"
echo "   توکن بات (از @BotFather)، آیدی عددی (از @userinfobot) و یک رمز برای پنل وارد کن."
echo "────────────────────────────────────────────"
