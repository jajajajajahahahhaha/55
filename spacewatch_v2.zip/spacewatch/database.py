"""SQLite storage (WAL mode, single shared connection, thread-safe).

Tables
  config        key/value settings (token, admin, flags)
  users         telegram users + language + per-user mute
  media         every fetched image/video (dedup by sha1)
  source_state  per-source ETag / Last-Modified / health / back-off
  sessions      web-panel login sessions (hashed tokens)
  events        ring-buffer of notable events for the panel
"""
import hashlib
import os
import secrets
import sqlite3
import threading
import time

import config

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS config(k TEXT PRIMARY KEY, v TEXT);

CREATE TABLE IF NOT EXISTS users(
    chat_id     INTEGER PRIMARY KEY,
    lang        TEXT DEFAULT 'fa',
    first_seen  REAL,
    muted       INTEGER DEFAULT 0,
    want_video  INTEGER DEFAULT 1,
    last_seen   REAL);

CREATE TABLE IF NOT EXISTS media(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    src         TEXT NOT NULL,
    url         TEXT,
    hash        TEXT UNIQUE,
    path        TEXT,
    kind        TEXT DEFAULT 'image',        -- image | video
    region      TEXT DEFAULT '',
    region_en   TEXT DEFAULT '',
    cc          TEXT DEFAULT '',
    lat REAL, lon REAL,
    sat         TEXT DEFAULT '',
    img_time    REAL,                        -- capture / publication time
    fetched_at  REAL,
    status      TEXT DEFAULT 'complete',     -- complete | partial
    width INTEGER DEFAULT 0, height INTEGER DEFAULT 0,
    size        INTEGER DEFAULT 0,
    duration    REAL DEFAULT 0,
    repaired_path TEXT,
    thumb_path  TEXT,
    rechecks    INTEGER DEFAULT 0,
    sent        INTEGER DEFAULT 0,
    tg_file_id  TEXT);                       -- reuse upload for other users
CREATE INDEX IF NOT EXISTS idx_media_f   ON media(fetched_at);
CREATE INDEX IF NOT EXISTS idx_media_src ON media(src, fetched_at);
CREATE INDEX IF NOT EXISTS idx_media_cc  ON media(cc);

CREATE TABLE IF NOT EXISTS source_state(
    key         TEXT PRIMARY KEY,
    etag        TEXT,
    last_mod    TEXT,
    last_hash   TEXT,
    last_ok     REAL,
    last_new    REAL,
    last_err    TEXT,
    fails       INTEGER DEFAULT 0,
    next_try    REAL DEFAULT 0,
    total_new   INTEGER DEFAULT 0,
    enabled     INTEGER DEFAULT 1,
    avg_ms      REAL DEFAULT 0);

CREATE TABLE IF NOT EXISTS sessions(
    tok_hash    TEXT PRIMARY KEY,
    created     REAL,
    expires     REAL,
    ip          TEXT);

CREATE TABLE IF NOT EXISTS events(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL, level TEXT, msg TEXT);
"""


# ---------------------------------------------------------------------------
def init(db_path=None):
    global _conn
    config.ensure_dirs()
    _conn = sqlite3.connect(db_path or config.DB_PATH, check_same_thread=False,
                            isolation_level=None)   # autocommit
    _conn.row_factory = sqlite3.Row
    _conn.execute("PRAGMA journal_mode=WAL")
    _conn.execute("PRAGMA synchronous=NORMAL")
    _conn.execute("PRAGMA temp_store=MEMORY")
    _conn.execute("PRAGMA cache_size=-4000")   # ~4 MB page cache, keep RAM low
    _conn.executescript(SCHEMA)
    _migrate()
    if cfg("first_run") is None:
        setcfg("first_run", str(time.time()))


def _migrate():
    """Upgrade from v1 (`images` table) without losing history."""
    with _lock:
        has_old = _conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='images'").fetchone()
        if has_old:
            n = _conn.execute("SELECT COUNT(*) c FROM media").fetchone()["c"]
            if n == 0:
                _conn.execute("""INSERT OR IGNORE INTO media
                    (src,url,hash,path,region,cc,lat,lon,sat,img_time,fetched_at,
                     status,width,height,size,repaired_path,rechecks,sent)
                    SELECT src,url,hash,path,region,cc,lat,lon,sat,img_time,fetched_at,
                     status,width,height,size,repaired_path,rechecks,1 FROM images""")
            _conn.execute("ALTER TABLE images RENAME TO images_v1_backup")
        # add columns that may be missing in older v2 dbs
        mcols = {r["name"] for r in _conn.execute("PRAGMA table_info(media)")}
        for col, ddl in (("region_en", "TEXT DEFAULT ''"), ("thumb_path", "TEXT"),
                         ("tg_file_id", "TEXT"), ("duration", "REAL DEFAULT 0"),
                         ("sent", "INTEGER DEFAULT 0"), ("kind", "TEXT DEFAULT 'image'")):
            if col not in mcols:
                _conn.execute(f"ALTER TABLE media ADD COLUMN {col} {ddl}")
        cols = {r["name"] for r in _conn.execute("PRAGMA table_info(users)")}
        for col, ddl in (("muted", "INTEGER DEFAULT 0"),
                         ("want_video", "INTEGER DEFAULT 1"),
                         ("last_seen", "REAL")):
            if col not in cols:
                _conn.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")


def _q(sql, args=()):
    with _lock:
        return _conn.execute(sql, args)


# ---------------------------------------------------------------- config ----
def cfg(k, default=None):
    r = _q("SELECT v FROM config WHERE k=?", (k,)).fetchone()
    return r["v"] if r else default


def setcfg(k, v):
    _q("INSERT INTO config(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
       (k, str(v)))


def delcfg(k):
    _q("DELETE FROM config WHERE k=?", (k,))


def flag(k, default=False):
    v = cfg(k)
    return default if v is None else v == "1"


# ----------------------------------------------------------------- users ----
def ensure_user(chat_id, lang=None):
    _q("INSERT OR IGNORE INTO users(chat_id, lang, first_seen, last_seen) VALUES(?,?,?,?)",
       (chat_id, lang or "fa", time.time(), time.time()))
    _q("UPDATE users SET last_seen=? WHERE chat_id=?", (time.time(), chat_id))


def get_user(chat_id):
    return _q("SELECT * FROM users WHERE chat_id=?", (chat_id,)).fetchone()


def get_users(active_only=True):
    if active_only:
        return _q("SELECT * FROM users WHERE muted=0").fetchall()
    return _q("SELECT * FROM users").fetchall()


def get_user_lang(chat_id):
    r = _q("SELECT lang FROM users WHERE chat_id=?", (chat_id,)).fetchone()
    return r["lang"] if r else "fa"


def set_user_lang(chat_id, lang):
    _q("UPDATE users SET lang=? WHERE chat_id=?", (lang, chat_id))


def set_user_flag(chat_id, col, val):
    assert col in ("muted", "want_video")
    _q(f"UPDATE users SET {col}=? WHERE chat_id=?", (1 if val else 0, chat_id))


def remove_user(chat_id):
    _q("DELETE FROM users WHERE chat_id=?", (chat_id,))


# ----------------------------------------------------------------- media ----
def media_exists(h):
    return _q("SELECT 1 FROM media WHERE hash=?", (h,)).fetchone() is not None


def insert_media(d):
    cols = ",".join(d.keys())
    qs = ",".join("?" * len(d))
    with _lock:
        cur = _conn.execute(f"INSERT INTO media({cols}) VALUES({qs})", tuple(d.values()))
        return cur.lastrowid


def get_media(mid):
    return _q("SELECT * FROM media WHERE id=?", (mid,)).fetchone()


def update_media(mid, **fields):
    if not fields:
        return
    sets = ",".join(f"{k}=?" for k in fields)
    _q(f"UPDATE media SET {sets} WHERE id=?", (*fields.values(), mid))


def media_since(ts, limit=40, kind=None):
    if kind:
        return _q("SELECT * FROM media WHERE fetched_at>=? AND kind=? "
                  "ORDER BY fetched_at DESC LIMIT ?", (ts, kind, limit)).fetchall()
    return _q("SELECT * FROM media WHERE fetched_at>=? ORDER BY fetched_at DESC LIMIT ?",
              (ts, limit)).fetchall()


def latest_by_src(src):
    return _q("SELECT * FROM media WHERE src=? ORDER BY fetched_at DESC LIMIT 1",
              (src,)).fetchone()


def latest_media(limit=12, kind=None):
    if kind:
        return _q("SELECT * FROM media WHERE kind=? ORDER BY fetched_at DESC LIMIT ?",
                  (kind, limit)).fetchall()
    return _q("SELECT * FROM media ORDER BY fetched_at DESC LIMIT ?", (limit,)).fetchall()


def partials_due(limit=4, max_rechecks=30):
    return _q("SELECT * FROM media WHERE status='partial' AND rechecks<? AND fetched_at>? "
              "ORDER BY fetched_at ASC LIMIT ?",
              (max_rechecks, time.time() - 6 * 3600, limit)).fetchall()


IRAN_ALIASES = ("iran", "ir", "ایران", "persia", "فارس", "tehran", "تهران")
ME_ALIASES = ("middle east", "خاورمیانه", "me", "mideast", "gulf", "خلیج", "arab")


def find_region(q, limit=1):
    ql = q.strip().lower()
    if ql in IRAN_ALIASES:
        r = _q("SELECT * FROM media WHERE cc='IR' OR region LIKE '%ایران%' OR region LIKE '%Iran%' "
               "OR (lat BETWEEN 24 AND 40 AND lon BETWEEN 43 AND 64) "
               "ORDER BY fetched_at DESC LIMIT ?", (limit,)).fetchall()
        if r:
            return r
    if ql in ME_ALIASES:
        r = _q("SELECT * FROM media WHERE cc IN ('IR','ME','SA','IQ','TR','AE','EG') "
               "OR region LIKE '%خاورمیانه%' OR region LIKE '%Middle East%' "
               "ORDER BY fetched_at DESC LIMIT ?", (limit,)).fetchall()
        if r:
            return r
    r = _q("SELECT * FROM media WHERE UPPER(cc)=? ORDER BY fetched_at DESC LIMIT ?",
           (ql.upper(), limit)).fetchall()
    if r:
        return r
    return _q("SELECT * FROM media WHERE LOWER(region) LIKE ? OR LOWER(sat) LIKE ? OR src LIKE ? "
              "ORDER BY fetched_at DESC LIMIT ?",
              (f"%{ql}%", f"%{ql}%", f"%{ql}%", limit)).fetchall()


def counts():
    r = _q("""SELECT
        (SELECT COUNT(*) FROM users) u,
        (SELECT COUNT(*) FROM media WHERE kind='image') i,
        (SELECT COUNT(*) FROM media WHERE kind='video') v,
        (SELECT COUNT(*) FROM media WHERE status='partial') p,
        (SELECT COALESCE(SUM(size),0) FROM media) bytes,
        (SELECT COUNT(*) FROM media WHERE fetched_at>?) last24""",
           (time.time() - 86400,)).fetchone()
    return dict(r)


def old_media(before_ts):
    return _q("SELECT id, path, repaired_path, thumb_path FROM media WHERE fetched_at<?",
              (before_ts,)).fetchall()


def delete_media_rows(ids):
    if not ids:
        return
    qs = ",".join("?" * len(ids))
    _q(f"DELETE FROM media WHERE id IN ({qs})", tuple(ids))


def per_source_stats():
    return _q("""SELECT m.src, COUNT(*) n, MAX(m.fetched_at) last,
                        SUM(CASE WHEN m.kind='video' THEN 1 ELSE 0 END) vids
                 FROM media m GROUP BY m.src""").fetchall()


# ---------------------------------------------------------- source_state ----
def src_state(key):
    r = _q("SELECT * FROM source_state WHERE key=?", (key,)).fetchone()
    if r:
        return dict(r)
    _q("INSERT OR IGNORE INTO source_state(key) VALUES(?)", (key,))
    return dict(_q("SELECT * FROM source_state WHERE key=?", (key,)).fetchone())


def src_update(key, **fields):
    if not fields:
        return
    _q("INSERT OR IGNORE INTO source_state(key) VALUES(?)", (key,))
    sets = ",".join(f"{k}=?" for k in fields)
    _q(f"UPDATE source_state SET {sets} WHERE key=?", (*fields.values(), key))


def src_ok(key, etag=None, last_mod=None, ms=0, new_item=False, last_hash=None):
    st = src_state(key)
    avg = st["avg_ms"] * 0.7 + ms * 0.3 if st["avg_ms"] else ms
    f = dict(last_ok=time.time(), fails=0, next_try=0, last_err=None, avg_ms=avg)
    if etag is not None:
        f["etag"] = etag
    if last_mod is not None:
        f["last_mod"] = last_mod
    if last_hash is not None:
        f["last_hash"] = last_hash
    if new_item:
        f["last_new"] = time.time()
        f["total_new"] = st["total_new"] + 1
    src_update(key, **f)


def src_fail(key, err):
    st = src_state(key)
    fails = st["fails"] + 1
    # exponential back-off: 60s, 120s, 240s ... capped
    delay = min(config.MAX_BACKOFF, 60 * (2 ** min(fails - 1, 6)))
    src_update(key, fails=fails, last_err=str(err)[:200], next_try=time.time() + delay)
    return delay


def src_all():
    return [dict(r) for r in _q("SELECT * FROM source_state ORDER BY key").fetchall()]


def src_set_enabled(key, enabled):
    src_update(key, enabled=1 if enabled else 0)


# -------------------------------------------------------------- sessions ----
def _h(tok):
    return hashlib.sha256(tok.encode()).hexdigest()


def session_create(ip=""):
    tok = secrets.token_urlsafe(32)
    now = time.time()
    _q("INSERT INTO sessions(tok_hash, created, expires, ip) VALUES(?,?,?,?)",
       (_h(tok), now, now + config.SESSION_HOURS * 3600, ip))
    _q("DELETE FROM sessions WHERE expires<?", (now,))
    return tok


def session_valid(tok):
    if not tok:
        return False
    r = _q("SELECT expires FROM sessions WHERE tok_hash=?", (_h(tok),)).fetchone()
    return bool(r and r["expires"] > time.time())


def session_drop(tok):
    if tok:
        _q("DELETE FROM sessions WHERE tok_hash=?", (_h(tok),))


def sessions_clear():
    _q("DELETE FROM sessions")


# ---------------------------------------------------------------- events ----
def event(level, msg):
    _q("INSERT INTO events(ts, level, msg) VALUES(?,?,?)", (time.time(), level, msg[:300]))
    _q("DELETE FROM events WHERE id < (SELECT MAX(id) FROM events) - 300")


def events(limit=40):
    return [dict(r) for r in
            _q("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]


def vacuum():
    with _lock:
        _conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        _conn.execute("PRAGMA optimize")


def disk_usage():
    total = 0
    for d in (config.IMG_DIR, config.VID_DIR, config.FILE_DIR):
        try:
            for f in os.scandir(d):
                if f.is_file():
                    total += f.stat().st_size
        except FileNotFoundError:
            pass
    return total
