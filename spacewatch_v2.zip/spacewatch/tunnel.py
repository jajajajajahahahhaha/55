"""Cloudflare quick-tunnel for serving >49MB files as direct download links.

Security: files are published under random, unguessable names and expire
after config.KEEP_DAYS; the file server binds to 127.0.0.1 only and never
lists directories. The tunnel is started lazily and restarted if it dies."""
import asyncio
import logging
import os
import re
import secrets
import shutil
import time

from aiohttp import web

import config

log = logging.getLogger("tunnel")
_url = None
_proc = None
_lock = asyncio.Lock()
_SAFE = re.compile(r"^[A-Za-z0-9_.-]{1,200}$")


def file_app():
    app = web.Application(client_max_size=1024)
    app.router.add_get("/dl/{name}", _dl)
    app.router.add_get("/healthz", lambda r: web.Response(text="ok"))
    return app


async def _dl(request):
    name = request.match_info["name"]
    if not _SAFE.match(name) or ".." in name:
        return web.Response(status=400, text="bad name")
    p = os.path.join(config.FILE_DIR, name)
    if not os.path.isfile(p):
        return web.Response(status=404, text="not found")
    return web.FileResponse(p, headers={
        "Content-Disposition": f'attachment; filename="{name.split("_", 1)[-1]}"',
        "X-Content-Type-Options": "nosniff", "Cache-Control": "private, max-age=0"})


def _alive():
    return _proc is not None and _proc.returncode is None


async def get_tunnel_url():
    global _url, _proc
    async with _lock:
        if _url and _alive():
            return _url
        _url = None
        exe = shutil.which("cloudflared") or (os.path.abspath("cloudflared")
                                              if os.path.exists("cloudflared") else None)
        if not exe:
            log.warning("cloudflared not found")
            return None
        try:
            _proc = await asyncio.create_subprocess_exec(
                exe, "tunnel", "--url", f"http://127.0.0.1:{config.FILE_PORT}",
                "--no-autoupdate", "--protocol", "http2",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            deadline = time.time() + 40
            while time.time() < deadline:
                try:
                    line = await asyncio.wait_for(_proc.stdout.readline(), 5)
                except asyncio.TimeoutError:
                    continue
                if not line:
                    break
                m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line.decode("utf8", "ignore"))
                if m:
                    _url = m.group(0)
                    log.info("tunnel up: %s", _url)
                    asyncio.create_task(_drain(_proc))
                    break
        except Exception as e:
            log.warning("tunnel failed: %s", e)
        return _url


async def _drain(proc):
    """Keep reading stdout so cloudflared never blocks on a full pipe."""
    try:
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
    except Exception:
        pass


async def publish_file(path, hint=None):
    """Copy to public dir under a random name and return a direct URL (or None)."""
    base = hint or os.path.basename(path)
    base = re.sub(r"[^A-Za-z0-9_.-]", "_", base)[:120]
    name = f"{secrets.token_urlsafe(12)}_{base}"
    dst = os.path.join(config.FILE_DIR, name)
    await asyncio.to_thread(shutil.copy2, path, dst)
    url = await get_tunnel_url()
    return f"{url}/dl/{name}" if url else None


def cleanup(max_age=86400):
    now = time.time()
    try:
        for f in os.scandir(config.FILE_DIR):
            if f.is_file() and now - f.stat().st_mtime > max_age:
                os.remove(f.path)
    except FileNotFoundError:
        pass
