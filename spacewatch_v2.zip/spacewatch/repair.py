"""Partial-image detection + lightweight OpenCV inpainting.

v2 changes
  * byte-level truncation check (PIL) — the only *certain* signal
  * visual check is opt-in per source (only Earth full-disk products) and
    ignores black margins, so Sun / deep-space imagery is never flagged
  * repair works on a downscaled copy for big images (RAM < ~60 MB)
"""
import io
import logging

import numpy as np
from PIL import Image, ImageFile

log = logging.getLogger("repair")
Image.MAX_IMAGE_PIXELS = None            # we control memory via draft()/thumbnail


def is_truncated(data: bytes) -> bool:
    """True when the byte stream is an incomplete JPEG/PNG."""
    ImageFile.LOAD_TRUNCATED_IMAGES = False
    try:
        im = Image.open(io.BytesIO(data))
        im.draft("L", (512, 512))          # cheap decode for JPEG
        im.load()
        return False
    except (OSError, SyntaxError) as e:
        return "truncated" in str(e).lower() or "broken" in str(e).lower() \
            or "incomplete" in str(e).lower()
    except Exception:
        return False
    finally:
        ImageFile.LOAD_TRUNCATED_IMAGES = True


def _gray_small(path, max_side=900):
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    im = Image.open(path)
    im.draft("L", (max_side, max_side))
    im = im.convert("L")
    im.thumbnail((max_side, max_side))
    return np.asarray(im, dtype=np.uint8)


def detect_partial(path, visual=True):
    """Heuristic for partially-rendered Earth disks: a *non-black* flat band
    (usually mid-gray) covering the bottom or right side while the upper
    part has real content."""
    try:
        g = _gray_small(path)
    except Exception as e:
        log.debug("detect_partial open failed: %s", e)
        return True                       # unreadable -> treat as partial
    if not visual:
        return False
    try:
        rs = g.std(axis=1)
        rm = g.mean(axis=1)
        n = len(rs)
        tail = slice(int(n * 0.6), n)
        flat_tail = (rs[tail] < 2.0)
        nonblack_tail = (rm[tail] > 12)
        tail_bad = (flat_tail & nonblack_tail).mean() > 0.6
        head_ok = (rs[: max(1, int(n * 0.45))] > 4).mean() > 0.4

        cs = g.std(axis=0)
        cm = g.mean(axis=0)
        right = slice(int(len(cs) * 0.85), len(cs))
        right_bad = ((cs[right] < 1.5) & (cm[right] > 12)).mean() > 0.9
        return bool((tail_bad and head_ok) or right_bad)
    except Exception as e:
        log.warning("detect_partial error: %s", e)
        return False


def try_repair(path, max_side=1400):
    """Inpaint flat bands. Returns repaired JPEG path or None."""
    try:
        import cv2
        ImageFile.LOAD_TRUNCATED_IMAGES = True
        pil = Image.open(path)
        pil.draft("RGB", (max_side, max_side))
        pil = pil.convert("RGB")
        pil.thumbnail((max_side, max_side))
        img = cv2.cvtColor(np.asarray(pil), cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        mask = np.zeros(gray.shape, np.uint8)

        rs, rm = gray.std(axis=1), gray.mean(axis=1)
        bad_rows = np.where((rs < 1.5) & (rm > 12))[0]
        if len(bad_rows) > 8 and bad_rows.max() >= gray.shape[0] - 2:
            start = bad_rows[0]
            if start > gray.shape[0] * 0.3:
                mask[start:, :] = 255

        cs, cm = gray.std(axis=0), gray.mean(axis=0)
        bad_cols = np.where((cs < 1.5) & (cm > 12))[0]
        if len(bad_cols) > 8 and bad_cols.max() >= gray.shape[1] - 2:
            start = bad_cols[0]
            if start > gray.shape[1] * 0.3:
                mask[:, start:] = 255

        frac = (mask > 0).mean()
        if frac == 0:
            return None
        if frac > 0.30:
            log.info("damage too large (%.0f%%) -> skip repair", frac * 100)
            return None
        mask = cv2.dilate(mask, np.ones((3, 3), np.uint8))
        repaired = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
        out = path.rsplit(".", 1)[0] + "_repaired.jpg"
        cv2.imwrite(out, repaired, [cv2.IMWRITE_JPEG_QUALITY, 92])
        return out
    except Exception as e:
        log.warning("repair failed: %s", e)
        return None


def is_dark(path, thresh=6.0):
    """Mostly-black render (night side of a visible-light WMS layer)."""
    try:
        g = _gray_small(path, 400)
        return float(g.mean()) < thresh
    except Exception:
        return False


def make_preview(path, out_path, max_side=2500, quality=88):
    """Downscaled JPEG for Telegram's sendPhoto (w+h<=10000, <10MB).
    Uses draft() so a 11k×12k JPEG decodes with ~30 MB RAM."""
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    im = Image.open(path)
    im.draft("RGB", (max_side, max_side))
    im = im.convert("RGB")
    im.thumbnail((max_side, max_side))
    im.save(out_path, "JPEG", quality=quality, optimize=True)
    return im.size
